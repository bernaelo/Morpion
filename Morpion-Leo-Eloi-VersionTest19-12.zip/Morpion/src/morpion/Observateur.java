/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author bernaelo
 */
public class Observateur implements Observer {

    private ArrayList<Joueur> joueurstournoi = new ArrayList<>();
    private VueTournoi vuetournoi;
    private VueSupprimerJoueur suppr;
    private VueAjouterJoueur ajouter;
    private VueMatch match;
    private HashMap<Integer,Match> matchsàfaire = new HashMap<>();
    private HashMap<Integer,Match> matchsfaits = new HashMap<>();
    
    
    Observateur() {
        
        vuetournoi = new VueTournoi(joueurstournoi);
        vuetournoi.addObserver(this);
        vuetournoi.afficher();
        suppr=null;
        ajouter=null;
        
    }
    
    @Override
    public void update(Observable o, Object arg) {
        
        
        // L'utilisateur a demandé à ajouter un joueur, sur l'interface VueTournoi
        if (arg instanceof Message) {
            Message message = (Message) arg ;
            if ((o instanceof VueTournoi) && message.getAction() == Actions.DEMANDE_AJOUT) {

                ajouter = new VueAjouterJoueur();
                ajouter.addObserver(this);
                ajouter.afficher();
                vuetournoi.close();
                
            }
            
        // L'utilisateur a validé la saisie du nouveau joueur
        
            else if ((o instanceof VueAjouterJoueur) && message.getAction() == Actions.ANNULER) {
                ajouter.close();
                vuetournoi.afficher();
            }
            
            else if ((o instanceof VueSupprimerJoueur) && message.getAction() == Actions.ANNULER) {
                suppr.close();
                vuetournoi.afficher();
            }
            
            else if ((o instanceof VueAjouterJoueur) && message.getAction() == Actions.VALIDER) {
                
                ajouterJoueur(message.getPseudo());
                ajouter.close();
                vuetournoi = new VueTournoi(joueurstournoi);
                vuetournoi.addObserver(this);
                vuetournoi.afficher();
                
                
            }
            
            // L'utilisateur a demandé à supprimer un joueur, sur l'interface VueTournoi
            
            else if ((o instanceof VueTournoi) && message.getAction() == Actions.DEMANDE_SUPPRIMER) {
                
                suppr = new VueSupprimerJoueur(joueurstournoi);
                suppr.addObserver(this);
                suppr.afficher();
                vuetournoi.close();
                
            }
            
            // L'utilisateur a validé la supression du joueur
            
            else if ((o instanceof VueSupprimerJoueur) && message.getAction() == Actions.VALIDER) {
                
                joueurstournoi.remove(message.getPosition());
                suppr.close();
                vuetournoi = new VueTournoi(joueurstournoi);
                vuetournoi.addObserver(this);
                vuetournoi.afficher();

                for(Joueur j : joueurstournoi){
                    System.out.println(j.getPseudo());
                }
                
            // L'utilisateur a décidé de commencer le tournoi, sur l'interface VueTournoi => Le premier match est joué
                
            }
            
            else if ((o instanceof VueTournoi) && message.getAction() == Actions.COMMENCER_TOURNOI) {
                
                if (joueurstournoi.size() >= 2) {
                   genererMatchs(joueurstournoi);
                   System.out.println("Premier match : "+matchsàfaire.get(1).getJ1().getPseudo()+ " VS "+matchsàfaire.get(1).getJ2().getPseudo());
                   match = new VueMatch(matchsàfaire.get(1));
                   match.addObserver(this);
                   match.afficher();
                   vuetournoi.close();
                }
            }
            
            // Vérification si le match en cours est terminé, si oui mise à jour des scores et lancement du match suivant si il en reste à faire
            
           else if ((o instanceof VueMatch) && message.getAction() == Actions.VALIDER) {
                
               Match matchjoué = jouermatch(message); 
               if (matchjoué.getEtatmatch() == EtatMatch.TERMINE) { // Vérification si le match est terminé
                   
                   if (matchjoué.getJgagnant() != null) {       // Mise à jour des scores
                       System.out.println("Match terminé ! Gagnant : "+matchjoué.getJgagnant().getPseudo());
                       matchjoué.getJgagnant().ajouterscoregagnant();
                   } else {
                       System.out.println("Match terminé ! Il y a eu match nul.");
                       matchjoué.getJ1().ajouterscorenul();
                       matchjoué.getJ2().ajouterscorenul();
                   }
                   
                   retirermatchàfaire(matchjoué);
                   
                   if (this.matchsàfaire.isEmpty() == false) {                  // Si il reste des matchs à faire, lancement du prochain match
                   System.out.println("Match suivant : "+matchsàfaire.get(matchjoué.getNumeromatch()+1).getJ1().getPseudo()+ " VS "+matchsàfaire.get(matchjoué.getNumeromatch()+1).getJ2().getPseudo());
                   match = new VueMatch(matchsàfaire.get(matchjoué.getNumeromatch()+1));
                   match.addObserver(this);
                   match.afficher(); }
                   
                   else {
                       System.out.println("Tournoi terminé");  //Affichage du classement (à faire)
                   VueClassement classementfinal = new VueClassement(genererListeClassement(joueurstournoi));
                   classementfinal.afficher();
                   } 
                   
               }
               
               
               
            }
        }
    }
        
    public void ajouterJoueur(String pseudo) {
        Joueur j = new Joueur(pseudo);
        joueurstournoi.add(j);
    }
        
    public void genererMatchs(ArrayList<Joueur> joueurstournoi) {  //Une fois la liste de joueurs pleines, on génère la liste des matchs pour que chaque joueur se rencontre.
               
       int numeromatch = 1;
        for (int k = 0; k < joueurstournoi.size(); k++) {
            for (int i = 0; i < joueurstournoi.size(); i++) {
                if (!(joueurstournoi.get(k).equals(joueurstournoi.get(i))) && i > k) {
                    
                    HashMap<Integer,Case> listecase = new HashMap<>();
                    for (int n = 1; n < 10; n++) {
                        Case c = new Case(n);
                        listecase.put(n, c);
                    }
                    
                    HashMap<Joueur,Signe> signejoueur = new HashMap<>();
                    signejoueur.put(joueurstournoi.get(k),Signe.O);
                    signejoueur.put(joueurstournoi.get(i),Signe.X);
                    
                    Match m = new Match(listecase,numeromatch, joueurstournoi.get(k), joueurstournoi.get(i), signejoueur);
                    
                    matchsàfaire.put(numeromatch,m);
                    numeromatch +=1;
                }
            }
        }
      
    }
        
    public Match jouermatch(Message message) {      // On récupère les cases cochées sur l'interface du match, pour vérifier si le match est terminé et voir si il y a un gagnant, si non on continue le match
                
                match.close();
                Match matchencours = message.getMatch();
                int casecochée = message.getIndicecase();
                Joueur jcourantmatch = matchencours.getJcourant();
                matchencours.getCases().get(message.getIndicecase()).setJoueurCasecochee(jcourantmatch); // On actualise l'état de la case cochée
                
                if (matchencours.getJcourant().equals(matchencours.getJ1())) {
                    matchencours.setJcourant(matchencours.getJ2());
                } else {
                    matchencours.setJcourant(matchencours.getJ1());
                }
                    
                    if ((matchencours.getCases().get(1).getJoueurCasecochee() != null) && (matchencours.getCases().get(1).getJoueurCasecochee().equals(matchencours.getCases().get(2).getJoueurCasecochee()))
                            && (matchencours.getCases().get(2).getJoueurCasecochee().equals(matchencours.getCases().get(3).getJoueurCasecochee()))) {
                        matchencours.setJgagnant(matchencours.getCases().get(1).getJoueurCasecochee());
                        matchencours.setEtatmatch(EtatMatch.TERMINE);
                    }
                    
                    else if ((matchencours.getCases().get(1).getJoueurCasecochee() != null) && (matchencours.getCases().get(1).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                            && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
                        matchencours.setJgagnant(matchencours.getCases().get(1).getJoueurCasecochee());
                        matchencours.setEtatmatch(EtatMatch.TERMINE);
                    }
       
                    else if ((matchencours.getCases().get(3).getJoueurCasecochee() != null) && (matchencours.getCases().get(3).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                            && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(7).getJoueurCasecochee()))) {
                        matchencours.setJgagnant(matchencours.getCases().get(3).getJoueurCasecochee());
                        matchencours.setEtatmatch(EtatMatch.TERMINE);
                    }
                
                    else if ((matchencours.getCases().get(4).getJoueurCasecochee() != null) && (matchencours.getCases().get(4).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                            && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(6).getJoueurCasecochee()))) {
                        matchencours.setJgagnant(matchencours.getCases().get(4).getJoueurCasecochee());
                        matchencours.setEtatmatch(EtatMatch.TERMINE);
                    }
                    
                    else if ((matchencours.getCases().get(7).getJoueurCasecochee() != null) && (matchencours.getCases().get(7).getJoueurCasecochee().equals(matchencours.getCases().get(8).getJoueurCasecochee()))
                            && (matchencours.getCases().get(8).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
                        matchencours.setJgagnant(matchencours.getCases().get(7).getJoueurCasecochee());
                        matchencours.setEtatmatch(EtatMatch.TERMINE);
                    }
                    
                    else if ((matchencours.getCases().get(7).getJoueurCasecochee() != null) && (matchencours.getCases().get(7).getJoueurCasecochee().equals(matchencours.getCases().get(8).getJoueurCasecochee()))
                            && (matchencours.getCases().get(8).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
                        matchencours.setJgagnant(matchencours.getCases().get(7).getJoueurCasecochee());
                        matchencours.setEtatmatch(EtatMatch.TERMINE);
                    }
                    
                    else if ((matchencours.getCases().get(1).getJoueurCasecochee() != null) && (matchencours.getCases().get(1).getJoueurCasecochee().equals(matchencours.getCases().get(4).getJoueurCasecochee()))
                            && (matchencours.getCases().get(4).getJoueurCasecochee().equals(matchencours.getCases().get(7).getJoueurCasecochee()))) {
                        matchencours.setJgagnant(matchencours.getCases().get(1).getJoueurCasecochee());
                        matchencours.setEtatmatch(EtatMatch.TERMINE);
                    }
                    
                    else if ((matchencours.getCases().get(2).getJoueurCasecochee() != null) && (matchencours.getCases().get(2).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                            && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(8).getJoueurCasecochee()))) {
                        matchencours.setJgagnant(matchencours.getCases().get(2).getJoueurCasecochee());
                        matchencours.setEtatmatch(EtatMatch.TERMINE);
                    }
                    
                    else if ((matchencours.getCases().get(3).getJoueurCasecochee() != null) && (matchencours.getCases().get(3).getJoueurCasecochee().equals(matchencours.getCases().get(6).getJoueurCasecochee()))
                            && (matchencours.getCases().get(6).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
                       matchencours.setJgagnant(matchencours.getCases().get(3).getJoueurCasecochee());
                       matchencours.setEtatmatch(EtatMatch.TERMINE);
                    }
                    
                    else {
                        
                        boolean matchnul = true;
                        
                        for (int k =1; k < matchencours.getCases().size(); k++) {
                            
                            if (matchencours.getCases().get(k).getJoueurCasecochee() == null) {
                                matchnul = false;
                            }
                             
                        }
                        
                        if (matchnul == true) {
                            matchencours.setEtatmatch(EtatMatch.TERMINE);
                        } else {
                        
                        System.out.println("Il n'y a pas encore de gagnant : C'est maintenant à "+matchencours.getJcourant().getPseudo()+" de jouer.");
                        match = new VueMatch(matchencours);
                        match.addObserver(this);
                        match.afficher();
                        
                    } 
               }
                    
                    return matchencours;
                    
           }
    
    public void retirermatchàfaire(Match match) {
               
               matchsàfaire.remove(match.getNumeromatch());
               matchsfaits.put(match.getNumeromatch(),match);
               
           }
    
    public ArrayList<Joueur> genererListeClassement(ArrayList<Joueur> listejoueurs) {
        
    ArrayList<Joueur> joueurstrié = listejoueurs;
    
        Collections.sort(joueurstrié, new ComparatorScore());
    
    return joueurstrié;
 
    }
    
        }