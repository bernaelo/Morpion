/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author Fayzy
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Observable;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class VueClassement {
    
    private final JFrame window;
    
    VueClassement(ArrayList<Joueur> listejoueurs) {
        window = new JFrame();
        
        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(500, 400);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width/2-window.getSize().width/2, dim.height/2-window.getSize().height/2);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);
        JPanel panelhaut = new JPanel();
        panelhaut.setBackground(Color.orange);
        JLabel titreclassement = new JLabel("~ Classement final ~");
        titreclassement.setFont(new Font("Arial",Font.BOLD,16));
        panelhaut.add(titreclassement);
        JPanel panelmilieu = new JPanel(new GridLayout(listejoueurs.size(),1));
        panelmilieu.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
        JPanel panelbas = new JPanel();
        JLabel merci = new JLabel("Merci d'avoir participé !");
        merci.setFont(new Font("Arial",Font.ITALIC,16));
        panelbas.add(merci);
        
        mainPanel.add(panelhaut, BorderLayout.NORTH);
        mainPanel.add(panelmilieu, BorderLayout.CENTER);
        mainPanel.add(panelbas, BorderLayout.SOUTH);
        
    int classement = 1;
        
        for (int i = 0; i < listejoueurs.size(); i++) {
            
            JLabel jl = new JLabel(classement+"."+" Joueur : "+listejoueurs.get(i).getPseudo()+"  |  "+"Points : "+listejoueurs.get(i).getScore(),SwingConstants.CENTER);
            jl.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1));
            jl.setFont(new Font("Arial",Font.PLAIN,16));
            panelmilieu.add(jl);
            classement++;
        }
        
    }

    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }
    
}
