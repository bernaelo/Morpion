/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author bernaelo
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueMatch extends Observable {
    
    private JFrame window;
    JButton boutonvalider;
    JPanel casepleine;
    private ButtonGroup bgroup;
    private JRadioButton case1;
    private JRadioButton case2;
    private JRadioButton case3;
    private JRadioButton case4;
    private JRadioButton case5;
    private JRadioButton case6;
    private JRadioButton case7;
    private JRadioButton case8;
    private JRadioButton case9;
    
    VueMatch(Match match) {
    
     window = new JFrame();
        
        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(800, 500);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width/2-window.getSize().width/2, dim.height/2-window.getSize().height/2);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);
        JPanel panelmilieu = new JPanel(new BorderLayout());
        JPanel panelmilieu1 = new JPanel(new GridLayout(4,3));
        JPanel panelmilieu2 = new JPanel(new GridLayout(3,3));
        JPanel panelbas = new JPanel(new GridLayout(3,4));
        panelmilieu.add(panelmilieu1, BorderLayout.NORTH);
        panelmilieu.add(panelmilieu2, BorderLayout.CENTER);
        JPanel panelhaut = new JPanel();
        JLabel titrejouer = new JLabel("Jouer un match");
        titrejouer.setFont(new Font("Arial",Font.BOLD,16));
        panelhaut.add(titrejouer);
        panelhaut.setBackground(Color.orange);
        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);
        mainPanel.add(BorderLayout.SOUTH, panelbas);
        
        boutonvalider = new JButton("Valider");
        bgroup = new ButtonGroup();
        
        case1 = new JRadioButton();
        case2 = new JRadioButton();
        case3 = new JRadioButton();
        case4 = new JRadioButton();
        case5 = new JRadioButton();
        case6 = new JRadioButton();
        case7 = new JRadioButton();
        case8 = new JRadioButton();
        case9 = new JRadioButton();
        
        bgroup.add(case1);
        bgroup.add(case2);
        bgroup.add(case3);
        bgroup.add(case4);
        bgroup.add(case5);
        bgroup.add(case6);
        bgroup.add(case7);
        bgroup.add(case8);
        bgroup.add(case9);
            
        
                for (int k = 1; k <= 12; k++) {
                
                    JLabel casevide = new JLabel("");
                    
                 
                   
                   if (k == 5) {
                       JLabel guidage = new JLabel("Match n°"+match.getNumeromatch()+" - C'est à "+match.getJcourant().getPseudo()+" de jouer !",SwingConstants.CENTER);
                       guidage.setFont(new Font("Arial",Font.ITALIC,16));
                       panelmilieu1.add(guidage); 
                     }
                   
                    else if (k == 7) {
                       JLabel infoj1 = new JLabel("Signe "+match.getSigne(match.getJ1()).toString()+" : "+match.getJ1().getPseudo(),SwingConstants.CENTER);
                       infoj1.setFont(new Font("Arial",Font.BOLD,16));
                        panelmilieu1.add(infoj1);
                     }
            
                     else if (k == 9) {
                        JLabel infoj2 = new JLabel("Signe "+match.getSigne(match.getJ2()).toString()+" : "+match.getJ2().getPseudo(),SwingConstants.CENTER);
                       infoj2.setFont(new Font("Arial",Font.BOLD,16));
                        panelmilieu1.add(infoj2);
                     }      
                   
                     else {
                     panelmilieu1.add(casevide);
                     }
                   
                } 
            
           for (int i = 1; i <= 9; i++) {
           
           JLabel casevide = new JLabel("");
           Font font = new Font("Arial",Font.BOLD,35);
           JLabel label1 = new JLabel(match.getSigne(match.getJ1()).toString()); label1.setFont(font); label1.setForeground(Color.red);
           JLabel label2 = new JLabel(match.getSigne(match.getJ2()).toString()); label2.setFont(font); label2.setForeground(Color.blue);
            
            if (i == 1) {
                
                if(match.getCases().get(1).getJoueurCasecochee()==match.getJ1()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label1);
                    casepleine.setBorder(BorderFactory.createLineBorder(Color.black,1)) ;
                    panelmilieu2.add(casepleine);
                } else if(match.getCases().get(1).getJoueurCasecochee()==match.getJ2()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label2);
                    casepleine.setBorder(BorderFactory.createLineBorder(Color.black,1)) ;
                    panelmilieu2.add(casepleine);
                } else{
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(case1);
                    casepleine.setBorder(BorderFactory.createLineBorder(Color.black,1)) ;
                    panelmilieu2.add(casepleine);
                }
                
            }
            
            else if (i == 2) {
                
                if(match.getCases().get(2).getJoueurCasecochee()==match.getJ1()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label1);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else if(match.getCases().get(2).getJoueurCasecochee()==match.getJ2()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label2);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else{
                    casepleine = new JPanel();
                    casepleine.add(case2); casepleine.setLayout(new GridBagLayout());
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                }
                
            }
            
            else if (i == 3) {
                
                if(match.getCases().get(3).getJoueurCasecochee()==match.getJ1()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label1);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else if(match.getCases().get(3).getJoueurCasecochee()==match.getJ2()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label2);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else{
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(case3);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                }
                
            }
            
            else if (i == 4) {
                
                if(match.getCases().get(4).getJoueurCasecochee()==match.getJ1()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label1);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else if(match.getCases().get(4).getJoueurCasecochee()==match.getJ2()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label2);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else{
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(case4);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                }
                
            }
            
            else if (i == 5) {
                
               if(match.getCases().get(5).getJoueurCasecochee()==match.getJ1()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label1);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else if(match.getCases().get(5).getJoueurCasecochee()==match.getJ2()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label2);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else{
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(case5); 
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                }
                
            }
            
            else if (i == 6) {
                
                if(match.getCases().get(6).getJoueurCasecochee()==match.getJ1()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label1);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else if(match.getCases().get(6).getJoueurCasecochee()==match.getJ2()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label2);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else{
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(case6);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                }
                
            }
            
            else if (i == 7) {
                
                if(match.getCases().get(7).getJoueurCasecochee()==match.getJ1()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label1);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else if(match.getCases().get(7).getJoueurCasecochee()==match.getJ2()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label2);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else{
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(case7);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                }
                
            }
            
            else if (i == 8) {
                
                if(match.getCases().get(8).getJoueurCasecochee()==match.getJ1()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label1);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else if(match.getCases().get(8).getJoueurCasecochee()==match.getJ2()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label2);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else{
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(case8);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                }
                
            }
            
            else if (i == 9) {
                
                if(match.getCases().get(9).getJoueurCasecochee()==match.getJ1()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label1);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else if(match.getCases().get(9).getJoueurCasecochee()==match.getJ2()){
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(label2);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                } else{
                    casepleine = new JPanel(); casepleine.setLayout(new GridBagLayout());
                    casepleine.add(case9);
                    casepleine.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
                    panelmilieu2.add(casepleine);
                }
                
            }
            
        }
           
                panelbas.add(new JLabel("")); panelbas.add(new JLabel("")); panelbas.add(new JLabel("")); panelbas.add(new JLabel("")); panelbas.add(new JLabel(""));
                JLabel valider = new JLabel("Valider la sélection : ",SwingConstants.CENTER);
                valider.setFont(new Font("Arial",Font.PLAIN,16));
                panelbas.add(valider);
                
                boutonvalider.addActionListener(new ActionListener() {
                @Override
                   public void actionPerformed(ActionEvent e) {
                        setChanged();
                        
                        int numcase = 0;
                        
                        if (case1.isSelected()){
                            numcase=1;
                        }
                        else if (case2.isSelected()){
                            numcase=2;
                        }
                        else if (case3.isSelected()){
                            numcase=3;
                        }
                        else if (case4.isSelected()){
                            numcase=4;
                        }
                        else if (case5.isSelected()){
                            numcase=5;
                        }
                        else if (case6.isSelected()){
                            numcase=6;
                        }
                        else if (case7.isSelected()){
                            numcase=7;
                        }
                        else if (case8.isSelected()){
                            numcase=8;
                        }
                        else if (case9.isSelected()){
                            numcase=9;
                        }
                        
                            if (numcase != 0) {
                            notifyObservers(new Message(Actions.VALIDER, match, numcase));}
                            
                        clearChanged();
                    }   
                });
                
                panelbas.add(boutonvalider);
                
                 panelbas.add(new JLabel(""));
                  panelbas.add(new JLabel(""));
                   panelbas.add(new JLabel(""));
                    panelbas.add(new JLabel(""));
                     panelbas.add(new JLabel(""));
           
    }
          
        
     public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }
    
}