/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Observable;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author kemplail
 */
public class VueTournoi extends Observable {

    private final JFrame window;
    private final JButton boutonajouter, boutonsupprimer, boutoncommencer;
    
    VueTournoi(ArrayList<Joueur> h) {
        
        window = new JFrame();
        
        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(800, 500);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width/2-window.getSize().width/2, dim.height/2-window.getSize().height/2);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);
        
        JPanel panelmilieu = new JPanel(new GridLayout(7,2));
        JPanel panelhaut = new JPanel();
        panelhaut.setBackground(Color.orange);
        JPanel panelgauche = new JPanel(new BorderLayout());
        JPanel panelliste = new JPanel(new GridLayout(3,1));
        JPanel panelbas = new JPanel();
        Font font = new Font("Arial",Font.PLAIN,16);
        JLabel info = new JLabel("Information : Veuillez ajouter au minimum 2 joueurs, pour commencer le tournoi"); info.setFont(new Font("Arial",Font.BOLD,14));
        panelbas.add(info);
        panelbas.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1)) ;
        
        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);
        mainPanel.add(BorderLayout.WEST, panelgauche);
        mainPanel.add(BorderLayout.SOUTH, panelbas);
        
        JLabel tournoi = new JLabel("Créer un tournoi",SwingConstants.CENTER);
        tournoi.setFont(new Font("Arial",Font.BOLD,16));
        panelhaut.add(tournoi);
        
        panelgauche.add(BorderLayout.NORTH, panelliste);
        panelliste.add(new JLabel(""));
        JLabel liste = new JLabel("  Liste des joueurs : ");
        liste.setFont(new Font("Arial",Font.ITALIC,16));
        panelliste.add(liste);
        panelliste.add(new JLabel(""));
        
        String[] joueurs = new String[h.size()];
                for(int c = 0;c<h.size();c++){
                    joueurs[c]=h.get(c).getPseudo();
                }
                JList listejoueurs;
                listejoueurs = new JList(joueurs);
               
        panelgauche.add(BorderLayout.CENTER, listejoueurs);
        
        boutonajouter = new JButton("Ajouter");
        boutonsupprimer = new JButton("Supprimer");
        boutoncommencer = new JButton("Commencer");
        
            for (int i = 1; i <= 14 ; i++) {
                
                JLabel casevide = new JLabel("");
                
                if (i == 4) {
                    
                    boutonajouter.addActionListener(new ActionListener() {
                @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                            notifyObservers(new Message(Actions.DEMANDE_AJOUT));
                        clearChanged();
            }   
        });
            panelmilieu.add(boutonajouter);
                    
                }
                
               else if (i == 3) {
                   
                   JLabel ajout = new JLabel("Ajouter un nouveau joueur : ",SwingConstants.CENTER);
                   ajout.setFont(font);
                   panelmilieu.add(ajout);
                   
               }
               
               else if (i == 7) {
                   
                   JLabel supprimer = new JLabel("Supprimer un joueur existant : ",SwingConstants.CENTER);
                   supprimer.setFont(font);
                   panelmilieu.add(supprimer);
                   
               }
               
               else if (i == 11) {
                   JLabel commencer = new JLabel("Commencer le tournoi : ",SwingConstants.CENTER);
                   commencer.setFont(font);
                   panelmilieu.add(commencer);
               }
                
               else if (i == 8) {
                    
            boutonsupprimer.addActionListener(new ActionListener() {
                @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                            notifyObservers(new Message(Actions.DEMANDE_SUPPRIMER));
                        clearChanged();
            }   
        });
            panelmilieu.add(boutonsupprimer);
                }
                
                else if (i == 12) {
                    
                    boutoncommencer.addActionListener(new ActionListener() {
                @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                            notifyObservers(new Message(Actions.COMMENCER_TOURNOI));
                        clearChanged();
            }   
        });
            panelmilieu.add(boutoncommencer);
                    
                }
                  
                else {
                    
                    panelmilieu.add(casevide);
                    
                }
                
            }
       
        }
        
    
    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }
    
}