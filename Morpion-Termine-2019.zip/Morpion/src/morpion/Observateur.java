/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;
import javax.swing.ImageIcon;

/**
 *
 * @author bernaelo
 */
public class Observateur implements Observer {

    private ArrayList<Joueur> joueurstournoi = new ArrayList<>();
    private VueTournoi vuetournoi;
    private VueTournoiEnfant vuetournoienfant;
    private VueInitialisation vueinit;
    private VueSupprimerJoueur suppr;
    private VueAjouterJoueur ajouter;
    private VueAjouterJoueurEnfant ajouterenfant;
    private VueSupprimerJoueurEnfant supprimerenfant;
    private VueMatch match;
    private VueMatchEnfant matchenfant;
    private VueRègles vueregles;
    private HashMap<Integer, Match> matchsàfaire = new HashMap<>();
    private HashMap<Integer, Match> matchsfaits = new HashMap<>();

    Observateur() {

        // On ouvre la première IHM, la vue d'Initialisation du tournoi
        
        vueinit = new VueInitialisation();
        vueinit.addObserver(this);
        vueinit.afficher();

    }

    @Override
    public void update(Observable o, Object arg) {

        if (arg instanceof Message) {
            Message message = (Message) arg;

            // Si l'utilisateur a décidé de choisir le mode adulte sur la Vue Initialisation, on ouvre l'interface VueTournoi (adaptée aux adultes), afin de configurer le tournoi
            if ((o instanceof VueInitialisation) && message.getAction() == Actions.MODE_ADULTE) {

                vueinit.close();
                vuetournoi = new VueTournoi(joueurstournoi);
                vuetournoi.addObserver(this);
                vuetournoi.afficher();

            // Si l'utilisateur a décidé de choisir le mode enfant sur la Vue Initialisation, on ouvre l'interface VueTournoiEnfant (adaptée aux enfants), afin de configurer le tournoi    
            } else if ((o instanceof VueInitialisation) && message.getAction() == Actions.MODE_ENFANT) {

                vueinit.close();
                vuetournoienfant = new VueTournoiEnfant(joueurstournoi);
                vuetournoienfant.addObserver(this);
                vuetournoienfant.afficher();

            } else if ((o instanceof VueInitialisation) && message.getAction() == Actions.DEMANDE_REGLES)   {
                
                vueregles = new VueRègles();
                vueregles.addObserver(this);
                vueregles.afficher();
                
            // Si sur une des 2 Vues Tournoi, l'utilisateur a décidé d'ajouter un joueur, on ouvre l'interface d'ajout d'un joueur, adaptée au mode choisi (enfant ou adulte)
            } else if ((o instanceof VueTournoi || o instanceof VueTournoiEnfant) && message.getAction() == Actions.DEMANDE_AJOUT) {

                // Cas ou la Vue tournoi est en mode adulte
                if (o instanceof VueTournoi) {

                    ajouter = new VueAjouterJoueur();
                    ajouter.addObserver(this);
                    ajouter.afficher();
                
                // Cas ou la Vue tournoi est en mode enfant
                } else {

                    ajouterenfant = new VueAjouterJoueurEnfant();
                    ajouterenfant.addObserver(this);
                    ajouterenfant.afficher();

                }

            } 
            // Si l'utilisateur a cliqué sur un bouton annuler, sur une interface d'ajout de joueur ou de suppression de joueurs, on ferme cette interface.
            else if (message.getAction() == Actions.ANNULER) {
                
                if (o instanceof VueAjouterJoueur || o instanceof VueAjouterJoueurEnfant) {

                    if (o instanceof VueAjouterJoueur) {
                        ((VueAjouterJoueur) o).close();
                    } else {
                        ((VueAjouterJoueurEnfant) o).close();
                    }

                } else {

                    if (o instanceof VueSupprimerJoueur) {
                        ((VueSupprimerJoueur) o).close();
                    } else {
                        ((VueSupprimerJoueurEnfant) o).close();
                        vuetournoienfant.actualiser(joueurstournoi);
                    }
                }
            // Si l'utilisateur a cliqué sur Validé, sur une interface d'ajout ou de suppression de joueurs, on ajoute/supprime le joueur de la liste des joueurs (méthodes ajouterJoueur()/joueurstournoi.remove())
            // Puis on ferme cette interface, et actualise l'interface Vue Tournoi pour mettre à jour la liste des joueurs sur celle-ci
            } else if (message.getAction() == Actions.VALIDER_CONFIG) {

                if (o instanceof VueAjouterJoueur || o instanceof VueAjouterJoueurEnfant) {
                    ajouterJoueur(message.getPseudo());

                    if (o instanceof VueAjouterJoueur) {
                        ((VueAjouterJoueur) o).close();
                        vuetournoi.actualiser(joueurstournoi);
                    } else {
                        ((VueAjouterJoueurEnfant) o).close();
                        vuetournoienfant.actualiser(joueurstournoi);
                    }

                } else {
                    joueurstournoi.remove(message.getPosition());

                    if (o instanceof VueSupprimerJoueur) {
                        ((VueSupprimerJoueur) o).close();
                        vuetournoi.actualiser(joueurstournoi);
                    } else {
                        ((VueSupprimerJoueurEnfant) o).close();
                        vuetournoienfant.actualiser(joueurstournoi);
                    }

                }

            } //Si sur une des 2 Vues Tournoi, l'utilisateur a décidé de supprimer un joueur, on ouvre l'interface de suppression d'un joueur, adaptée au mode choisi (enfant ou adulte)
            else if (((o instanceof VueTournoi) || (o instanceof VueTournoiEnfant)) && message.getAction() == Actions.DEMANDE_SUPPRIMER) {

                if (o instanceof VueTournoi) {

                    suppr = new VueSupprimerJoueur(joueurstournoi);
                    suppr.addObserver(this);
                    suppr.afficher();

                } else {

                    supprimerenfant = new VueSupprimerJoueurEnfant(joueurstournoi);
                    supprimerenfant.addObserver(this);
                    supprimerenfant.afficher();

                }

                // Si l'utilisateur a cliqué sur Commencer le tournoi, sur la Vue Tournoi, d'abord on verifie qu'il y ai au moins 2 joueurs
                // S'il n'y a pas 2 joueurs, on fait apparaître un message d'erreur sur l'interface, et le tournoi n'est pas généré
            } else if (message.getAction() == Actions.COMMENCER_TOURNOI) {

                if (joueurstournoi.size() >= 2) {
                    
                    // Si il y a assez de joueurs, on génère l'ensemble des matchs
                    
                    genererMatchs(joueurstournoi);
                    System.out.println("Premier match : " + matchsàfaire.get(1).getJ1().getPseudo() + " VS " + matchsàfaire.get(1).getJ2().getPseudo());

                    // On lance alors le premier match à faire, avec une interface de Match là aussi adaptée au mode choisi (enfant/adulte)
                    if (o instanceof VueTournoi) {
                        
                        match = new VueMatch(matchsàfaire.get(1));
                        match.addObserver(this);
                        match.afficher();
                        vuetournoi.close();
                    } else {

                        matchenfant = new VueMatchEnfant(matchsàfaire.get(1));
                        matchenfant.addObserver(this);
                        matchenfant.afficher();
                        vuetournoienfant.close();

                    }

                } else {
                    if (o instanceof VueTournoi) {
                        ((VueTournoi) o).declenchererreur();
                    } else {
                        ((VueTournoiEnfant) o).declenchererreur();
                    }
                } 
            } 
            // Si l'utilisateur, dans la Vue d'un match, a coché une des cases
            //On va vérifier l'état du match, avec la méthode jouermatch()
            else if ((o instanceof VueMatch || o instanceof VueMatchEnfant) && message.getAction() == Actions.VALIDER) {

                Match matchjoué = jouermatch(message, o);
                // On regarde si le match retourné par jouermatch est terminé
                if (matchjoué.getEtatmatch() == EtatMatch.TERMINE) { 

                    if (matchjoué.getJgagnant() != null) {       // Si il est terminé, on regarde si il y a un gagnant, on met à jour les scores
                        System.out.println("Match terminé ! Gagnant : " + matchjoué.getJgagnant().getPseudo());
                        matchjoué.getJgagnant().ajouterscoregagnant();
                    } else {
                        System.out.println("Match terminé ! Il y a eu match nul.");
                        matchjoué.getJ1().ajouterscorenul();
                        matchjoué.getJ2().ajouterscorenul();
                    }

                    // On retire ce match des matchs à faire
                    retirermatchàfaire(matchjoué);

                    // Si il est terminé, on regarde aussi si il reste d'autres matchs à faire, si oui : lancement du prochain match / si non : on affiche le classement final
                    if (this.matchsàfaire.isEmpty() == false) {                  
                        System.out.println("Match suivant : " + matchsàfaire.get(matchjoué.getNumeromatch() + 1).getJ1().getPseudo() + " VS " + matchsàfaire.get(matchjoué.getNumeromatch() + 1).getJ2().getPseudo());

                        if (o instanceof VueMatch) {

                            match = new VueMatch(matchsàfaire.get(matchjoué.getNumeromatch() + 1));
                            match.addObserver(this);
                            match.afficher();

                        } else {

                            matchenfant = new VueMatchEnfant(matchsàfaire.get(matchjoué.getNumeromatch() + 1));
                            matchenfant.addObserver(this);
                            matchenfant.afficher();

                        }
                    } else {
                        System.out.println("Tournoi terminé"); 
                        
                        if (o instanceof VueMatch) {
                        
                        VueClassement classementfinal = new VueClassement(genererListeClassement(joueurstournoi));
                        classementfinal.afficher(); } 
                        
                        else {
                            
                        VueClassementEnfant classementfinal = new VueClassementEnfant(genererListeClassement(joueurstournoi));
                        classementfinal.afficher(); } 
                            
                        }
                    

                }

            }
        }
    }

    // ********************************** PARTIE METHODES : ********************************************
    
    public void ajouterJoueur(String pseudo) {
        Joueur j = new Joueur(pseudo);
        joueurstournoi.add(j);
    }

    // Une fois qu'on a tous nos joueurs participants dans la liste, on génère la liste des matchs en faisant en sorte que chaque joueur se rencontre
    public void genererMatchs(ArrayList<Joueur> joueurstournoi) {  

        int numeromatch = 1;
        for (int k = 0; k < joueurstournoi.size(); k++) {
            for (int i = 0; i < joueurstournoi.size(); i++) {
                if (!(joueurstournoi.get(k).equals(joueurstournoi.get(i))) && i > k) {

                    HashMap<Integer, Case> listecase = new HashMap<>();
                    for (int n = 1; n < 10; n++) {
                        Case c = new Case(n);
                        listecase.put(n, c);
                    }

                    HashMap<Joueur, Signe> signejoueur = new HashMap<>();
                    signejoueur.put(joueurstournoi.get(k), Signe.O);
                    signejoueur.put(joueurstournoi.get(i), Signe.X);

                    Match m = new Match(listecase, numeromatch, joueurstournoi.get(k), joueurstournoi.get(i), signejoueur);
                    
                    //On crée chaque match, avec 9 cases, un numero de matchs, 2 joueurs qui s'affrontent et des signes qui leurs sont attribués

                    matchsàfaire.put(numeromatch, m); // On ajoute ces matchs dans les matchs à faire
                    numeromatch += 1;
                }
            }
        }

    }
    // Méthode pour récupérer le match en cours, actualiser son état en fonction de la case validée et décider de la suite des traitements
    public Match jouermatch(Message message, Observable o) { 

        Match matchencours = message.getMatch();
        Joueur jcourantmatch = matchencours.getJcourant();
        matchencours.getCases().get(message.getIndicecase()).setJoueurCasecochee(jcourantmatch); // On actualise l'état de la case cochée

        // On change le joueur courant
        if (matchencours.getJcourant().equals(matchencours.getJ1())) {
            matchencours.setJcourant(matchencours.getJ2());
        } else {
            matchencours.setJcourant(matchencours.getJ1());
        }

        // Gros PAVE de code, afin de vérifier s'il y a 3 cases d'alignées qui sont cochées par le même joueur : si oui, le match est terminé, il y a un gagnant, et on ferme l'interface de match
        if ((matchencours.getCases().get(1).getJoueurCasecochee() != null) && (matchencours.getCases().get(1).getJoueurCasecochee().equals(matchencours.getCases().get(2).getJoueurCasecochee()))
                && (matchencours.getCases().get(2).getJoueurCasecochee().equals(matchencours.getCases().get(3).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(1).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            if (o instanceof VueMatch) {
                ((VueMatch) o).close();
            } else {
                ((VueMatchEnfant) o).close();
            }

        } else if ((matchencours.getCases().get(1).getJoueurCasecochee() != null) && (matchencours.getCases().get(1).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(1).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            if (o instanceof VueMatch) {
                ((VueMatch) o).close();
            } else {
                ((VueMatchEnfant) o).close();
            }

        } else if ((matchencours.getCases().get(3).getJoueurCasecochee() != null) && (matchencours.getCases().get(3).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(7).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(3).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            if (o instanceof VueMatch) {
                ((VueMatch) o).close();
            } else {
                ((VueMatchEnfant) o).close();
            }

        } else if ((matchencours.getCases().get(4).getJoueurCasecochee() != null) && (matchencours.getCases().get(4).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(6).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(4).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            if (o instanceof VueMatch) {
                ((VueMatch) o).close();
            } else {
                ((VueMatchEnfant) o).close();
            }

        } else if ((matchencours.getCases().get(7).getJoueurCasecochee() != null) && (matchencours.getCases().get(7).getJoueurCasecochee().equals(matchencours.getCases().get(8).getJoueurCasecochee()))
                && (matchencours.getCases().get(8).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(7).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            if (o instanceof VueMatch) {
                ((VueMatch) o).close();
            } else {
                ((VueMatchEnfant) o).close();
            }

        } else if ((matchencours.getCases().get(7).getJoueurCasecochee() != null) && (matchencours.getCases().get(7).getJoueurCasecochee().equals(matchencours.getCases().get(8).getJoueurCasecochee()))
                && (matchencours.getCases().get(8).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(7).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            if (o instanceof VueMatch) {
                ((VueMatch) o).close();
            } else {
                ((VueMatchEnfant) o).close();
            }

        } else if ((matchencours.getCases().get(1).getJoueurCasecochee() != null) && (matchencours.getCases().get(1).getJoueurCasecochee().equals(matchencours.getCases().get(4).getJoueurCasecochee()))
                && (matchencours.getCases().get(4).getJoueurCasecochee().equals(matchencours.getCases().get(7).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(1).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            if (o instanceof VueMatch) {
                ((VueMatch) o).close();
            } else {
                ((VueMatchEnfant) o).close();
            }

        } else if ((matchencours.getCases().get(2).getJoueurCasecochee() != null) && (matchencours.getCases().get(2).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(8).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(2).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            if (o instanceof VueMatch) {
                ((VueMatch) o).close();
            } else {
                ((VueMatchEnfant) o).close();
            }

        } else if ((matchencours.getCases().get(3).getJoueurCasecochee() != null) && (matchencours.getCases().get(3).getJoueurCasecochee().equals(matchencours.getCases().get(6).getJoueurCasecochee()))
                && (matchencours.getCases().get(6).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(3).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            if (o instanceof VueMatch) {
                ((VueMatch) o).close();
            } else {
                ((VueMatchEnfant) o).close();
            }

        } else {

            boolean matchnul = true;

            // ici, on vérifie si il y a match nul ou non
            for (int k = 1; k < matchencours.getCases().size(); k++) {

                if (matchencours.getCases().get(k).getJoueurCasecochee() == null) {
                    matchnul = false;
                }

            }

            // Si il y a match nul, on déclare que le match est terminé, on ferme l'interface
            if (matchnul == true) {
                matchencours.setEtatmatch(EtatMatch.TERMINE);

                if (o instanceof VueMatch) {

                    match.close();
                } else {
                    matchenfant.close();
                }
            } else {

                //Si on a pas détecté que le match est terminé : on actualise simplement l'interface de match, et le match continue
                if (o instanceof VueMatch) {
                    if (jcourantmatch == matchencours.getJ1()) {
                        match.getLbouton().get(message.getIndicecase() - 1).setIcon(new ImageIcon("src/morpion/case_rond.png"));
                        match.getGuidage().setText("Match n°" + matchencours.getNumeromatch() + " - " + "A " + matchencours.getJ2().getPseudo() + " ! - Sélectionne une case");
                    } else {
                        match.getLbouton().get(message.getIndicecase() - 1).setIcon(new ImageIcon("src/morpion/case_croix.png"));
                        match.getGuidage().setText("Match n°" + matchencours.getNumeromatch() + " - " + "A " + matchencours.getJ1().getPseudo() + " ! - Sélectionne une case");
                    }

                } else {
                    if (jcourantmatch == matchencours.getJ1()) {
                        matchenfant.getLbouton().get(message.getIndicecase() - 1).setIcon(new ImageIcon("src/morpion/case_rond.png"));
                        matchenfant.getFleche2().setVisible(true);
                        matchenfant.getFleche().setVisible(false);
                    } else {
                        matchenfant.getLbouton().get(message.getIndicecase() - 1).setIcon(new ImageIcon("src/morpion/case_croix.png"));
                        matchenfant.getFleche2().setVisible(false);
                        matchenfant.getFleche().setVisible(true);
                    }
                }
            }
        }

        return matchencours;

    }

    // Méthode pour retirer un match des matchs à faire, si il est terminé
    public void retirermatchàfaire(Match match) {

        matchsàfaire.remove(match.getNumeromatch());
        matchsfaits.put(match.getNumeromatch(), match);

    }

    // Méthode pour trier les joueurs et les afficher dans l'ordre du meilleur au moins bon, dans l'interface de classement, en fonction de leur score
    public ArrayList<Joueur> genererListeClassement(ArrayList<Joueur> listejoueurs) {

        ArrayList<Joueur> joueurstrié = listejoueurs;
        Collections.sort(joueurstrié, new ComparatorScore());
        return joueurstrié;

    }

}