/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueAjouterJoueurEnfant extends Observable {

    private JFrame window;
    private JTextField champseudo;
    JButton boutonvalider, boutonannuler;

    VueAjouterJoueurEnfant() {

        window = new JFrame();

        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(600, 400);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);
        
        JPanel panelmilieu = new JPanel(new GridLayout(4, 2));
        panelmilieu.setBackground(Color.orange);
        
        JPanel panelhaut = new JPanel();
        panelhaut.setBackground(Color.green);
        JLabel titreajout = new JLabel("NOUVEAU JOUEUR");
        titreajout.setFont(new Font("Comic sans MS", Font.BOLD, 26));
        titreajout.setForeground(Color.blue);
        panelhaut.add(titreajout);
        
        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);

        boutonvalider = new JButton(new ImageIcon("src/morpion/btn_valider.png"));
        boutonannuler = new JButton(new ImageIcon("src/morpion/btn_annuler.png"));

        // Ajout des champs texte / Labels / boutons dans le panel du milieu
        for (int i = 1; i <= 8; i++) {

            JLabel casevide = new JLabel("");

            if (i == 3) {

                JLabel prenom = new JLabel("Je m'appelle...", SwingConstants.CENTER);
                prenom.setFont(new Font("Comic sans MS", Font.BOLD, 24));
                panelmilieu.add(prenom);

            } else if (i == 4) {

                champseudo = new JTextField();
                champseudo.setFont(new Font("Comic sans MS", Font.PLAIN, 24));
                panelmilieu.add(champseudo);

            } else if (i == 7) {

                boutonvalider.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.VALIDER_CONFIG, champseudo.getText()));
                        clearChanged();
                    }
                });
                panelmilieu.add(boutonvalider);

            } else if (i == 8) {

                boutonannuler.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.ANNULER, champseudo.getText()));
                        clearChanged();
                    }
                });
                panelmilieu.add(boutonannuler);

            } else {
                panelmilieu.add(casevide);
            }

        }

    }

    public void afficher() {
        this.window.setVisible(true);
    }

    public void close() {
        this.window.dispose();
    }

}
