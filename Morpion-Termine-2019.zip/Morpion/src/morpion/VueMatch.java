/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author bernaelo
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueMatch extends Observable {

    private JFrame window;
    private ArrayList<JToggleButton> lbouton = new ArrayList<>();
    private JLabel guidage;
    private JLabel erreur;

    VueMatch(Match match) {

        window = new JFrame();

        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(1200, 625);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);

        JPanel panelmilieu = new JPanel(new BorderLayout());

        JPanel panelmilieu1 = new JPanel(new GridLayout(2, 3));
        JPanel panelmilieu2 = new JPanel(new GridLayout(3, 3));

        panelmilieu.add(panelmilieu1, BorderLayout.NORTH);
        panelmilieu.add(panelmilieu2, BorderLayout.CENTER);

        JPanel panelbas = new JPanel(new GridLayout(1, 3));

        JPanel panelhaut = new JPanel();
        JLabel titrejouer = new JLabel("Jouer un match");
        titrejouer.setFont(new Font("Arial", Font.BOLD, 24));
        panelhaut.add(titrejouer);
        panelhaut.setBackground(Color.orange);

        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);
        mainPanel.add(BorderLayout.SOUTH, panelbas);

        JButton boutonvalider = new JButton("Valider la sélection");
        boutonvalider.setFont(new Font("Arial", Font.PLAIN, 18));
        boutonvalider.setPreferredSize(new Dimension(100, 75));
        ButtonGroup bgroup = new ButtonGroup();

        // Ajout des éléments d'informations sur le match, dans le panel milieu n°1 (Signes, joueurs etc..)
        for (int k = 1; k <= 6; k++) {

            JLabel casevide = new JLabel("");

            if (k == 2) {
                guidage = new JLabel("Match n°" + match.getNumeromatch() + " - " + "A " + match.getJcourant().getPseudo() + " ! - Sélectionne une case", SwingConstants.CENTER);
                guidage.setFont(new Font("Arial", Font.ITALIC, 18));
                panelmilieu1.add(guidage);
            } else if (k == 1) {
                JLabel img1 = new JLabel(new ImageIcon("src/morpion/case_rond.png"));
                img1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                img1.setPreferredSize(new Dimension(72, 85));
                panelmilieu1.add(img1);
            } else if (k == 3) {
                JLabel img2 = new JLabel(new ImageIcon("src/morpion/case_croix.png"));
                img2.setPreferredSize(new Dimension(72, 85));
                panelmilieu1.add(img2);
            } else if (k == 4) {
                JLabel infoj1 = new JLabel(match.getJ1().getPseudo(), SwingConstants.CENTER);
                infoj1.setFont(new Font("Arial", Font.BOLD, 20));
                panelmilieu1.add(infoj1);
            } else if (k == 5) {
                erreur = new JLabel("");
                panelmilieu1.add(erreur);
            } else if (k == 6) {
                JLabel infoj2 = new JLabel(match.getJ2().getPseudo(), SwingConstants.CENTER);
                infoj2.setFont(new Font("Arial", Font.BOLD, 20));
                panelmilieu1.add(infoj2);
            } else {
                panelmilieu1.add(casevide);
            }

        }

        // Ajout de la grille de 9 cases, dans le panel milieu n°2
        for (int i = 1; i <= 9; i++) {

            JToggleButton bt = new JToggleButton("");
            bt.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1));
            bgroup.add(bt);
            lbouton.add(bt);
            panelmilieu2.add(bt);

        }

        panelbas.add(new JLabel(""));

        // Bouton valider pour valider sa sélection de case
        boutonvalider.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setChanged();
                
                // Lorsque l'utilisateur valide, on vérifie si la case est déjà prise ou non, si oui, on ne transmet rien au contrôleur et on fait apparaître un message d'erreur sur l'interface
                for (int j = 0; j < getLbouton().size(); j++) {
                    if (getLbouton().get(j).isSelected()) {
                        if (lbouton.get(j).getIcon() == null) {
                            notifyObservers(new Message(Actions.VALIDER, match, j + 1));
                            erreur.setVisible(false);
                            erreur.revalidate();
                        } else {
                            this.declenchererreur(); // Apparition du message d'erreur sur l'interface
                        } 
                    }
                }

                clearChanged();
            }

            private void declenchererreur() {
                erreur.setText("ERREUR : Cette case est déjà validée");
                erreur.setHorizontalAlignment(0);
                erreur.setFont(new Font("Arial", Font.BOLD, 16));
                erreur.setForeground(Color.red);
                erreur.setVisible(true);
                erreur.revalidate();
            }
        });

        panelbas.add(boutonvalider);

        panelbas.add(new JLabel(""));

    }

    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }

    /**
     * @return the lbouton
     */
    public ArrayList<JToggleButton> getLbouton() {
        return lbouton;
    }

    /**
     * @return the guidage
     */
    public JLabel getGuidage() {
        return guidage;
    }

}
