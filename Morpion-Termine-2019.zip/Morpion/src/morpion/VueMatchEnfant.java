/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueMatchEnfant extends Observable {

    private JFrame window;
    private ArrayList<JButton> lbouton = new ArrayList<>();
    private JLabel fleche;
    private JLabel fleche2;
    private JLabel erreur;

    VueMatchEnfant(Match match) {

        window = new JFrame();

        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(800, 600);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);

        JPanel panelmilieu = new JPanel(new BorderLayout());

        JPanel panelmilieu1 = new JPanel(new GridLayout(3, 3));
        panelmilieu1.setBackground(Color.orange);
        JPanel panelmilieu2 = new JPanel(new GridLayout(3, 3));

        panelmilieu.add(panelmilieu1, BorderLayout.NORTH);
        panelmilieu.add(panelmilieu2, BorderLayout.CENTER);

        JPanel panelbas = new JPanel(new GridLayout(1, 3));

        JPanel panelhaut = new JPanel();
        JLabel titrejouer = new JLabel("JOUER");
        titrejouer.setFont(new Font("Comic Sans MS", Font.BOLD, 26));
        titrejouer.setForeground(Color.blue);
        panelhaut.add(titrejouer);
        panelhaut.setBackground(Color.green);

        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);
        mainPanel.add(BorderLayout.SOUTH, panelbas);

        ButtonGroup bgroup = new ButtonGroup();

        // Ajout des éléments d'informations sur le match, dans le panel milieu n°1 (Signes, joueurs etc..)
        for (int k = 1; k <= 9; k++) {

            JLabel casevide = new JLabel("");

            if (k == 1) {
                JLabel infoj1 = new JLabel(match.getJ1().getPseudo(), SwingConstants.CENTER);
                infoj1.setFont(new Font("Comic Sans MS", Font.BOLD, 24));
                infoj1.setForeground(Color.red);
                panelmilieu1.add(infoj1);
            } else if (k == 3) {
                JLabel infoj2 = new JLabel(match.getJ2().getPseudo(), SwingConstants.CENTER);
                infoj2.setFont(new Font("Comic Sans MS", Font.BOLD, 24));
                infoj2.setForeground(Color.red);
                panelmilieu1.add(infoj2);
            } else if (k == 4) {
                JLabel img1 = new JLabel(new ImageIcon("src/morpion/case_rond.png"), SwingConstants.HORIZONTAL);
                img1.setPreferredSize(new Dimension(72, 72));
                panelmilieu1.add(img1);
            } else if (k == 6) {
                JLabel img2 = new JLabel(new ImageIcon("src/morpion/case_croix.png"), SwingConstants.HORIZONTAL);
                img2.setPreferredSize(new Dimension(72, 72));
                panelmilieu1.add(img2);
            } else if (k == 5) {
                JLabel infomatch = new JLabel(new ImageIcon("src/morpion/logo_vs.png"), SwingConstants.HORIZONTAL);
                infomatch.setPreferredSize(new Dimension(72, 72));
                panelmilieu1.add(infomatch);
            } else if (k == 7) {
                fleche = new JLabel(new ImageIcon("src/morpion/fleche.png"), SwingConstants.HORIZONTAL);
                panelmilieu1.add(fleche);
            } else if (k == 8) {
                erreur = new JLabel("");
                panelmilieu1.add(erreur);
            } else if (k == 9) {
                fleche2 = new JLabel(new ImageIcon("src/morpion/fleche.png"), SwingConstants.HORIZONTAL);
                fleche2.setVisible(false);
                panelmilieu1.add(fleche2);
            } else {
                panelmilieu1.add(casevide);
            }
        }

        // Ajout de la grille de 9 cases, dans le panel milieu n°2
        for (int i = 1; i <= 9; i++) {

            JButton bt = new JButton("");
            bt.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1));
            bgroup.add(bt);
            // les cases de l'interface (sous forme de boutons) sont présentes dans une Arraylist avec des indices
            lbouton.add(bt);

            int nb = i;

            bt.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    setChanged();

                    // On vérifie si la case sélectionnée  par l'utilisateur est déjà prise ou non, si oui, on ne transmet rien au contrôleur et on fait apparaître un message d'erreur sur l'interface
                    if (lbouton.get(nb - 1).getIcon() == null) {
                        notifyObservers(new Message(Actions.VALIDER, match, nb));
                        erreur.setVisible(false);
                        erreur.revalidate();
                    } else {
                        declenchererreur(); // Apparition du message d'erreur sur l'interface
                    }

                    clearChanged();
                }
                
            private void declenchererreur() {
                erreur.setText("Choisis une autre case !");
                erreur.setHorizontalAlignment(0);
                erreur.setFont(new Font("Arial", Font.BOLD, 16));
                erreur.setForeground(Color.red);
                erreur.setVisible(true);
                erreur.revalidate();
            }
                
            });

            panelmilieu2.add(bt);
        }
    }

    /**
     * @return the lbouton
     */
    public ArrayList<JButton> getLbouton() {
        return lbouton;
    }

    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }

    /**
     * @return the fleche
     */
    public JLabel getFleche() {
        return fleche;
    }

    /**
     * @return the fleche2
     */
    public JLabel getFleche2() {
        return fleche2;
    }

}
