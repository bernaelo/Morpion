/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;

/**
 *
 * @author Fayzy
 */
public class VueTournoiEnfant extends Observable {

    private final JFrame window;
    JPanel panelliste;
    JPanel panelgauche;
    JLabel erreur;

    VueTournoiEnfant(ArrayList<Joueur> h) {

        window = new JFrame();

        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);

        // Définit la taille de la fenêtre en pixels
        window.setSize(800, 500);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);

        JPanel panelcentre = new JPanel(new BorderLayout());
        JPanel panelmilieu = new JPanel(new GridLayout(2, 3));
        panelmilieu.setBackground(Color.orange);
        panelcentre.add(panelmilieu, BorderLayout.CENTER);
        erreur = new JLabel("");
        panelcentre.add(BorderLayout.SOUTH, erreur);
        
        JPanel panelhaut = new JPanel();
        panelhaut.setBackground(Color.green);
        JLabel titre = new JLabel("         JEU DU MORPION");
        titre.setForeground(Color.blue);
        titre.setFont(new Font("Comic Sans MS", Font.BOLD, 26));
        panelhaut.add(titre);
        
        panelgauche = new JPanel(new BorderLayout());
        
        panelliste = new JPanel(new GridLayout(3, 1));
         panelliste.add(new JLabel(""));
        JLabel liste = new JLabel("  PRENOMS : ");
        liste.setFont(new Font("Arial", Font.ITALIC, 16));
        panelliste.add(liste);
        panelliste.add(new JLabel(""));

        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelcentre);
        mainPanel.add(BorderLayout.WEST, panelgauche);

        // Méthode pour afficher la liste des joueurs, qui peut être actualisée si un joueur est ajouté à cette liste
        actualiser(h);

        JButton ajouterjoueur = new JButton(new ImageIcon("src/morpion/add-user.png"));
        JButton supprjoueur = new JButton(new ImageIcon("src/morpion/remove-user.png"));
        JButton commencer = new JButton(new ImageIcon("src/morpion/Start-icon.png"));

        // Ajout des boutons, images, labels au panel du milieu
        for (int i = 1; i <= 6; i++) {

            JLabel casevide = new JLabel("");

            if (i == 2) {

                JLabel image = new JLabel(new ImageIcon("src/morpion/image-enfant.jpg"));
                panelmilieu.add(image);

            } else if (i == 4) {

                ajouterjoueur.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.DEMANDE_AJOUT));
                        erreur.setVisible(false);
                        erreur.revalidate();
                        clearChanged();
                    }
                });
                panelmilieu.add(ajouterjoueur);

            } else if (i == 5) {

                supprjoueur.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.DEMANDE_SUPPRIMER));
                        clearChanged();
                    }
                });
                panelmilieu.add(supprjoueur);

            } else if (i == 6) {

                commencer.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.COMMENCER_TOURNOI));
                        clearChanged();
                    }
                });
                panelmilieu.add(commencer);

            } else {

                panelmilieu.add(casevide);

            }

        }

    }

    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }

    void actualiser(ArrayList<Joueur> h) {

        panelgauche.removeAll();
        panelgauche.add(BorderLayout.NORTH, panelliste);
        String[] joueurs = new String[h.size()];
        for (int c = 0; c < h.size(); c++) {
            joueurs[c] = h.get(c).getPseudo();
        }
        JList listejoueurs;
        listejoueurs = new JList(joueurs);
        listejoueurs.setFont(new Font("Arial", Font.PLAIN, 16));

        panelgauche.add(BorderLayout.CENTER, listejoueurs);
        panelgauche.revalidate();

    }
    
    // Méthode pour déclencher une erreur, si l'utilisateur n'a pas ajouté au moins 2 joueurs
    void declenchererreur() {
        
        erreur.setText("Il faut que tu ajoutes encore des joueurs pour commencer ! ");
        erreur.setHorizontalAlignment(0);
        erreur.setFont(new Font("Arial", Font.BOLD, 20));
        erreur.setForeground(Color.red);
        erreur.setVisible(true);
        erreur.revalidate();
        
    }

}
