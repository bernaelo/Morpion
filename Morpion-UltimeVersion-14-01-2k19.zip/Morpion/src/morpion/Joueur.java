/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author kemplail
 */
public class Joueur {

    /**
     * @return the score
     */
    public int getScore() {
        return score;
    }

    /**
     * @param score the score to set
     */
    public void setScore(int score) {
        this.score = score;
    }

    private String pseudo;
    private int score;

    Joueur(String pseudo) {
        this.setPseudo(pseudo);
        score = 0;
    }

    /**
     * @return the pseudo
     */
    public String getPseudo() {
        return pseudo;
    }

    /**
     * @param pseudo the pseudo to set
     */
    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public void ajouterscoregagnant() {
        this.setScore(this.getScore() + 3);
    }

    public void ajouterscorenul() {
        this.setScore(this.getScore() + 1);
    }

}
