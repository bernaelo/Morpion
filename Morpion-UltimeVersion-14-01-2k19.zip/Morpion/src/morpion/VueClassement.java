/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author Fayzy
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class VueClassement {

    private final JFrame window;
    private JPanel mainPanel;

    VueClassement(ArrayList<Joueur> listejoueurs, Actions mode) {
        window = new JFrame();

        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(500, 400);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);

        //Si le mode choisi est adulte, on affiche l'interface en mode adulte, en mode enfant sinon
        if (mode == Actions.MODE_ADULTE) {
            affichageadulte(listejoueurs);
        } else {
            affichageenfant(listejoueurs);
        }

    }

    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }

    // ** METHODE POUR AFFICHAGE DE L'INTERFACE EN MODE ADULTE **
    public void affichageadulte(ArrayList<Joueur> listejoueurs) {

        JPanel panelhaut = new JPanel();
        panelhaut.setBackground(Color.orange);
        JLabel titreclassement = new JLabel("~ Classement final ~");
        titreclassement.setFont(new Font("Arial", Font.BOLD, 24));
        panelhaut.add(titreclassement);

        JPanel panelmilieu = new JPanel(new GridLayout(listejoueurs.size(), 1));
        panelmilieu.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1));

        JPanel panelbas = new JPanel();
        JLabel merci = new JLabel("Merci d'avoir participé !");
        merci.setFont(new Font("Arial", Font.ITALIC, 20));
        panelbas.add(merci);

        mainPanel.add(panelhaut, BorderLayout.NORTH);
        mainPanel.add(panelmilieu, BorderLayout.CENTER);
        mainPanel.add(panelbas, BorderLayout.SOUTH);

        int classement = 1;

        // Pour chaque joueur de la liste des joueurs triés par ordre de score, on génère un JLabel avec sa place, son pseudo, ses points..
        for (int i = 0; i < listejoueurs.size(); i++) {

            JLabel jl = new JLabel(classement + "." + " Joueur : " + listejoueurs.get(i).getPseudo() + "  |  " + "Points : " + listejoueurs.get(i).getScore(), SwingConstants.CENTER);
            jl.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1));
            jl.setFont(new Font("Arial", Font.PLAIN, 18));
            panelmilieu.add(jl);
            classement++;
        }

    }

    // **METHODE POUR AFFICHAGE DE L'INTERFACE EN MODE ENFANT **
    public void affichageenfant(ArrayList<Joueur> listejoueurs) {

        JPanel panelhaut = new JPanel();
        panelhaut.setBackground(Color.green);
        JLabel titreclassement = new JLabel("~ RESULTATS ~");
        titreclassement.setFont(new Font("Comic Sans MS", Font.BOLD, 26));
        titreclassement.setForeground(Color.blue);
        panelhaut.add(titreclassement);

        JPanel panelmilieu = new JPanel(new GridLayout(4, 3));
        panelmilieu.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1));

        mainPanel.add(panelhaut, BorderLayout.NORTH);
        mainPanel.add(panelmilieu, BorderLayout.CENTER);

        Font font = new Font("Comic Sans MS", Font.PLAIN, 22);

        int nbj = listejoueurs.size();
        int classement = 1;

        // Création graphique d'un petit podium, faisant apparaître les pseudos 3 premiers joueurs sur celui-ci
        for (int i = 1; i <= 12; i++) {

            if (i == 2) {

                JLabel jl = new JLabel(listejoueurs.get(0).getPseudo(), SwingConstants.CENTER);
                jl.setFont(font);
                jl.setForeground(Color.red);
                panelmilieu.add(jl);
                nbj--;

            } else if (i == 4) {

                JLabel jl = new JLabel(listejoueurs.get(1).getPseudo(), SwingConstants.CENTER);
                jl.setFont(font);
                panelmilieu.add(jl);
                nbj--;

            } else if (i == 9) {

                if (nbj > 0) {
                    JLabel jl = new JLabel(listejoueurs.get(2).getPseudo(), SwingConstants.CENTER);
                    jl.setFont(font);
                    panelmilieu.add(jl);
                } else {
                    panelmilieu.add(new JLabel(""));
                }

            } else if (i == 7 || i == 8 || i == 5 || i > 9) {
                JPanel podium = new JPanel();

                if (i == 7 || i == 5 || i == 12) {

                    JLabel position = new JLabel(String.valueOf(classement));
                    position.setForeground(Color.WHITE);
                    classement++;
                    podium.add(position);
                    position.setFont(new Font("Arial", Font.BOLD, 26));

                }

                podium.setBackground(Color.black);
                panelmilieu.add(podium);
            } else {
                panelmilieu.add(new JLabel(""));
            }
        }

    }

}
