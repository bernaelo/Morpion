/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueInitialisation extends Observable {

    private JFrame window;

    VueInitialisation() {

        window = new JFrame();

        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(800, 500);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);

        JPanel panelhaut = new JPanel();
        panelhaut.setBackground(Color.orange);
        JLabel init = new JLabel("Initialiser le tournoi", SwingConstants.CENTER);
        init.setFont(new Font("Arial", Font.BOLD, 28));
        panelhaut.add(init);

        JPanel panelmilieu = new JPanel(new GridLayout(3, 2));

        mainPanel.add(panelmilieu, BorderLayout.CENTER);
        mainPanel.add(panelhaut, BorderLayout.NORTH);

        // Ajout des labels, boutons dans le panel du milieu
        for (int i = 1; i <= 6; i++) {

            if (i == 1) {
                JButton imageadulte = new JButton(new ImageIcon("src/morpion/icone_adulte.png"));

                imageadulte.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.MODE_ADULTE));
                        clearChanged();
                    }
                });

                panelmilieu.add(imageadulte);
            } else if (i == 2) {

                JLabel modeadulte = new JLabel("Tournoi Adulte", SwingConstants.CENTER);
                modeadulte.setFont(new Font("Arial", Font.BOLD, 26));
                panelmilieu.add(modeadulte);

            } else if (i == 3) {
                JButton imageenfant = new JButton(new ImageIcon("src/morpion/icone_enfant.png"));

                imageenfant.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.MODE_ENFANT));
                        clearChanged();
                    }
                });

                panelmilieu.add(imageenfant);
            } else if (i == 4) {

                JLabel modeenfant = new JLabel("Tournoi Enfant", SwingConstants.CENTER);
                modeenfant.setFont(new Font("Arial", Font.BOLD, 26));
                modeenfant.setForeground(Color.red);
                panelmilieu.add(modeenfant);

            } else if (i == 5) {

                JButton imageregles = new JButton(new ImageIcon("src/morpion/icone_regles.png"));

                imageregles.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.DEMANDE_REGLES));
                        clearChanged();
                    }
                });

                panelmilieu.add(imageregles);

            } else if (i == 6) {

                JLabel regles = new JLabel("Règles", SwingConstants.CENTER);
                regles.setFont(new Font("Arial", Font.ITALIC, 28));
                panelmilieu.add(regles);

            }

        }
    }

    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }

}
