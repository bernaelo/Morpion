/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.Observable;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueRègles extends Observable {

    private JFrame window;
    private JButton fermer;

    VueRègles() {

        window = new JFrame();
        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(800, 500);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);

        JPanel panelhaut = new JPanel();
        panelhaut.setBackground(Color.orange);
        JLabel titre = new JLabel("Règles", SwingConstants.CENTER);
        titre.setFont(new Font("Arial", Font.BOLD, 28));
        panelhaut.add(titre);
        mainPanel.add(BorderLayout.NORTH, panelhaut);

        // Zone de texte
        JTextArea zonetexte = new JTextArea(8, 20);
        zonetexte.setText("\n ************************************************************************************************************************ \n\n Chaque joueur participant au tournoi organisé, s'affrontera lors d'un match. \n Lors d'un match, c'est le premier joueur qui arrive à aligner en ligne de 3 cases (en diagonale \n ou non) "
                + "avec son signe qui remporte la victoire. \n Si personne ne réussi et que toutes les cases ont été remplies, il y a égalité. \n\n Le gagnant d'un match obtient 3 points, le perdant 0. En cas d'égalité, \n chaque"
                + " joueur obtient 1 point. \n\n Lorsque tous les matchs ont été joués, un classement c'est affiché. C'est le joueur avec le plus \n de points qui gagne. \n\n "
                + "************************************************************************************************************************ \n");

        zonetexte.setFont(new Font("Arial", Font.PLAIN, 18));

        mainPanel.add(BorderLayout.CENTER, zonetexte);

        JPanel panelbas = new JPanel(new GridLayout(1, 3));
        mainPanel.add(BorderLayout.SOUTH, panelbas);

        panelbas.add(new JLabel(""));

        fermer = new JButton("Fermer");
        fermer.setFont(new Font("Arial", Font.PLAIN, 18));
        fermer.setPreferredSize(new Dimension(100, 75));

        fermer.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                window.dispose();
            }
        }
        );

        panelbas.add(fermer);
        panelbas.add(new JLabel(""));

    }

    void afficher() {
        window.setVisible(true);
    }

    void close() {
        window.dispose();
    }

}
