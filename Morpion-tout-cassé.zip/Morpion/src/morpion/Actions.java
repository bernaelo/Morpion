/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author kemplail
 */
public enum Actions {
    DEMANDE_AJOUT,
    DEMANDE_SUPPRIMER,
    COMMENCER_TOURNOI,
    VALIDER,
    VALIDER_CONFIG,
    ANNULER,
    CREER_TOURNOI,
    DEMANDE_REGLES,
    CHANGE_MODE
}
