/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author kemplail
 */
public class Joueur {

    private String pseudo;
    private int score;
    private Mode typej;
    /**
     * @return the score
     */
    public int getScore() {
        return score;
    }

    /**
     * @param score the score to set
     */
    public void setScore(int score) {
        this.score = score;
    }


    Joueur(String pseudo,Mode typej) {
        this.setPseudo(pseudo);
        score = 0;
        this.typej=typej;
    }

    /**
     * @return the pseudo
     */
    public String getPseudo() {
        return pseudo;
    }

    /**
     * @param pseudo the pseudo to set
     */
    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public void ajouterscoregagnant() {
        this.setScore(this.getScore() + 3);
    }

    public void ajouterscorenul() {
        this.setScore(this.getScore() + 1);
    }

    /**
     * @return the typej
     */
    public Mode getTypej() {
        return typej;
    }

    /**
     * @param typej the typej to set
     */
    public void setTypej(Mode typej) {
        this.typej = typej;
    }

}
