/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;
import javax.swing.ImageIcon;

/**
 *
 * @author bernaelo
 */
public class Observateur implements Observer {

    private ArrayList<Joueur> joueurstournoi = new ArrayList<>(); //Joueurs participants au tournoi
    private VueTournoi vuetournoi;
    private VueInitialisation vueinit;
    private VueSupprimerJoueur suppr;
    private VueAjouterJoueur ajouter;
    private VueMatch match;
    private VueRègles vueregles;
    private VueClassement classementfinal;
    private HashMap<Integer, Match> matchsàfaire = new HashMap<>(); //Matchs restants
    private HashMap<Integer, Match> matchsfaits = new HashMap<>(); //Matchs faits

    Observateur() {

        // On ouvre la première IHM, la vue d'Initialisation du tournoi
        vueinit = new VueInitialisation();
        vueinit.addObserver(this);
        vueinit.afficher();

    }

    @Override
    public void update(Observable o, Object arg) {

        if (arg instanceof Message) {
            Message message = (Message) arg;

            // Si l'utilisateur a décidé de choisir le mode adulte sur la Vue Initialisation, on met le mode en MODE_ADULTE, et on ouvre l'interface VueTournoi adaptée selon le mode, afin de configurer le tournoi
            if ((o instanceof VueInitialisation) && message.getAction() == Actions.CREER_TOURNOI) {

                vueinit.close();
                vuetournoi = new VueTournoi(joueurstournoi);
                vuetournoi.addObserver(this);
                vuetournoi.afficher();

//                // Si l'utilisateur a décidé de choisir le mode adulte sur la Vue Initialisation, on met le mode en MODE_ENFANT, et on ouvre l'interface VueTournoi adaptée selon le mode, afin de configurer le tournoi   
//            } else if ((o instanceof VueInitialisation) && message.getAction() == Actions.MODE_ENFANT) {
//
//                mode = Actions.MODE_ENFANT;
//                vueinit.close();
//                vuetournoi = new VueTournoi(joueurstournoi, mode);
//                vuetournoi.addObserver(this);
//                vuetournoi.afficher();

                // Si l'utilisateur a décidé de consulter les règles, on ouvre l'interface de règles
            } else if ((o instanceof VueInitialisation) && message.getAction() == Actions.DEMANDE_REGLES) {

                vueregles = new VueRègles();
                vueregles.addObserver(this);
                vueregles.afficher();

                // Si sur la Vue Tournoi, l'utilisateur a décidé d'ajouter un joueur, on ouvre l'interface d'ajout d'un joueur, adaptée au mode préalabelement choisi
            } else if ((o instanceof VueTournoi) && message.getAction() == Actions.DEMANDE_AJOUT) {

                ajouter = new VueAjouterJoueur(vuetournoi.getMode());
                ajouter.addObserver(this);
                ajouter.afficher();

            }
                // change le mode de la vue tournoi
            else if ((o instanceof VueTournoi) && message.getAction() == Actions.CHANGE_MODE) {
                
                if(vuetournoi.getMode()==Mode.ADULTE){
                    vuetournoi.setMode(Mode.ENFANT);
                }else{
                    vuetournoi.setMode(Mode.ADULTE);
                }
                
                vuetournoi.revalider(joueurstournoi);
                
                
            }
            // Si l'utilisateur a cliqué sur un bouton annuler, sur une interface d'ajout de joueur ou de suppression de joueurs, on ferme cette interface.
            else if (message.getAction() == Actions.ANNULER) {

                if (o instanceof VueAjouterJoueur) {

                    ((VueAjouterJoueur) o).close();

                } else {

                    ((VueSupprimerJoueur) o).close();

                }

                // Si l'utilisateur a cliqué sur Validé, sur une interface d'ajout ou de suppression de joueurs, on ajoute/supprime le joueur de la liste des joueurs (méthodes ajouterJoueur()/joueurstournoi.remove())
                // Puis on ferme cette interface, et actualise l'interface Vue Tournoi pour mettre à jour la liste des joueurs sur celle-ci
            } else if (message.getAction() == Actions.VALIDER_CONFIG) {

                if (o instanceof VueAjouterJoueur) {
                    Mode m;
                    if (message.getIndex()==0){
                        m=Mode.ADULTE;
                    }else{
                        m=Mode.ENFANT;
                    }
                    ajouterJoueur(message.getPseudo(),m);

                    ((VueAjouterJoueur) o).close();
                    vuetournoi.actualiser(joueurstournoi);

                } else {
                    joueurstournoi.remove(message.getPosition());

                    ((VueSupprimerJoueur) o).close();
                    vuetournoi.actualiser(joueurstournoi);

                }

            } //Si sur la Vue Tournoi, l'utilisateur a décidé de supprimer un joueur, on ouvre l'interface de suppression d'un joueur, adaptée au mode préalabelement choisi
            else if ((o instanceof VueTournoi) && message.getAction() == Actions.DEMANDE_SUPPRIMER) {

                if (o instanceof VueTournoi) {

                    suppr = new VueSupprimerJoueur(joueurstournoi, vuetournoi.getMode());
                    suppr.addObserver(this);
                    suppr.afficher();

                }

                // Si l'utilisateur a cliqué sur Commencer le tournoi, sur la Vue Tournoi, on verifie  d'abordqu'il y ai au moins 2 joueurs
                // S'il n'y a pas 2 joueurs, on fait apparaître un message d'erreur sur l'interface, et le tournoi n'est pas généré    
            } else if (message.getAction() == Actions.COMMENCER_TOURNOI) {

                if (joueurstournoi.size() >= 2) {

                    // Si il y a assez de joueurs, on génère l'ensemble des matchs
                    genererMatchs(joueurstournoi);
                    System.out.println("Premier match : " + matchsàfaire.get(1).getJ1().getPseudo() + " VS " + matchsàfaire.get(1).getJ2().getPseudo());

                    // On lance alors le premier match à faire, avec une interface de Match là aussi adaptée au mode choisi
                    match = new VueMatch(matchsàfaire.get(1));
                    match.addObserver(this);
                    match.afficher();
                    vuetournoi.close();

                } else {

                    ((VueTournoi) o).declenchererreur();

                }

            } // Si l'utilisateur, dans la Vue d'un match, a coché une des cases
            //On va vérifier l'état du match, avec la méthode jouermatch()
            else if ((o instanceof VueMatch) && message.getAction() == Actions.VALIDER) {

                Match matchjoué = jouermatch(message, o);
                
                // On regarde si le match retourné par jouermatch est terminé
                if (matchjoué.getEtatmatch() == EtatMatch.TERMINE) {

                    if (matchjoué.getJgagnant() != null) {       // Si il est terminé, on regarde si il y a un gagnant, on met à jour les scores
                        System.out.println("Match terminé ! Gagnant : " + matchjoué.getJgagnant().getPseudo());
                        matchjoué.getJgagnant().ajouterscoregagnant();
                    } else {
                        System.out.println("Match terminé ! Il y a eu match nul.");
                        matchjoué.getJ1().ajouterscorenul();
                        matchjoué.getJ2().ajouterscorenul();
                    }

                    // On retire ce match des matchs à faire
                    retirermatchàfaire(matchjoué);

                    // Si il est terminé, on regarde aussi si il reste d'autres matchs à faire, si oui : lancement du prochain match / si non : on affiche le classement final
                    if (this.matchsàfaire.isEmpty() == false) {
                        System.out.println("Match suivant : " + matchsàfaire.get(matchjoué.getNumeromatch() + 1).getJ1().getPseudo() + " VS " + matchsàfaire.get(matchjoué.getNumeromatch() + 1).getJ2().getPseudo());

                        match = new VueMatch(matchsàfaire.get(matchjoué.getNumeromatch() + 1));
                        match.addObserver(this);
                        match.afficher();

                    } else {
                        System.out.println("Tournoi terminé");

                        classementfinal = new VueClassement(genererListeClassement(joueurstournoi));
                        classementfinal.afficher();

                    }

                }else{
                    match.revalider(matchjoué);
                }

            }
        }

    }

    // ********************************** PARTIE METHODES : ********************************************
    public void ajouterJoueur(String pseudo, Mode m) {
        Joueur j = new Joueur(pseudo,m);
        joueurstournoi.add(j);
    }

    // Une fois qu'on a tous nos joueurs participants dans la liste, on génère la liste des matchs en faisant en sorte que chaque joueur se rencontre
    public void genererMatchs(ArrayList<Joueur> joueurstournoi) {

        int numeromatch = 1;
        for (int k = 0; k < joueurstournoi.size(); k++) {
            for (int i = 0; i < joueurstournoi.size(); i++) {
                if (!(joueurstournoi.get(k).equals(joueurstournoi.get(i))) && i > k) {
                    
                    HashMap<Integer, Case> listecase = new HashMap<>();
                    for (int n = 1; n < 10; n++) {
                        Case c = new Case(n);
                        listecase.put(n, c);
                    }

                    HashMap<Joueur, Signe> signejoueur = new HashMap<>();
                    signejoueur.put(joueurstournoi.get(k), Signe.O);
                    signejoueur.put(joueurstournoi.get(i), Signe.X);

                    Match m = new Match(listecase, numeromatch, joueurstournoi.get(k), joueurstournoi.get(i), signejoueur);

                    //On crée chaque match, avec 9 cases, un numero de matchs, 2 joueurs qui s'affrontent et des signes qui leurs sont attribués
                    matchsàfaire.put(numeromatch, m); // On ajoute ces matchs dans les matchs à faire
                    numeromatch += 1;
                }
            }
        }

    }

    // Méthode pour récupérer le match en cours, actualiser son état en fonction de la case validée et décider de la suite des traitements
    public Match jouermatch(Message message, Observable o) {

        Match matchencours = message.getMatch();
        Joueur jcourantmatch = matchencours.getJcourant();
        matchencours.getCases().get(message.getIndicecase()).setJoueurCasecochee(jcourantmatch); // On actualise l'état de la case cochée

        // On change le joueur courant
        if (matchencours.getJcourant().equals(matchencours.getJ1())) {
            matchencours.setJcourant(matchencours.getJ2());
        } else {
            matchencours.setJcourant(matchencours.getJ1());
        }

        // Gros PAVE de code, afin de vérifier s'il y a 3 cases d'alignées qui sont cochées par le même joueur : si oui, le match est terminé, il y a un gagnant, et on ferme l'interface de match
        if ((matchencours.getCases().get(1).getJoueurCasecochee() != null) && (matchencours.getCases().get(1).getJoueurCasecochee().equals(matchencours.getCases().get(2).getJoueurCasecochee()))
                && (matchencours.getCases().get(2).getJoueurCasecochee().equals(matchencours.getCases().get(3).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(1).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            ((VueMatch) o).close();

        } else if ((matchencours.getCases().get(1).getJoueurCasecochee() != null) && (matchencours.getCases().get(1).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(1).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            ((VueMatch) o).close();

        } else if ((matchencours.getCases().get(3).getJoueurCasecochee() != null) && (matchencours.getCases().get(3).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(7).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(3).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            ((VueMatch) o).close();

        } else if ((matchencours.getCases().get(4).getJoueurCasecochee() != null) && (matchencours.getCases().get(4).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(6).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(4).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            ((VueMatch) o).close();

        } else if ((matchencours.getCases().get(7).getJoueurCasecochee() != null) && (matchencours.getCases().get(7).getJoueurCasecochee().equals(matchencours.getCases().get(8).getJoueurCasecochee()))
                && (matchencours.getCases().get(8).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(7).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            ((VueMatch) o).close();

        } else if ((matchencours.getCases().get(7).getJoueurCasecochee() != null) && (matchencours.getCases().get(7).getJoueurCasecochee().equals(matchencours.getCases().get(8).getJoueurCasecochee()))
                && (matchencours.getCases().get(8).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(7).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            ((VueMatch) o).close();

        } else if ((matchencours.getCases().get(1).getJoueurCasecochee() != null) && (matchencours.getCases().get(1).getJoueurCasecochee().equals(matchencours.getCases().get(4).getJoueurCasecochee()))
                && (matchencours.getCases().get(4).getJoueurCasecochee().equals(matchencours.getCases().get(7).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(1).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            ((VueMatch) o).close();

        } else if ((matchencours.getCases().get(2).getJoueurCasecochee() != null) && (matchencours.getCases().get(2).getJoueurCasecochee().equals(matchencours.getCases().get(5).getJoueurCasecochee()))
                && (matchencours.getCases().get(5).getJoueurCasecochee().equals(matchencours.getCases().get(8).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(2).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            ((VueMatch) o).close();

        } else if ((matchencours.getCases().get(3).getJoueurCasecochee() != null) && (matchencours.getCases().get(3).getJoueurCasecochee().equals(matchencours.getCases().get(6).getJoueurCasecochee()))
                && (matchencours.getCases().get(6).getJoueurCasecochee().equals(matchencours.getCases().get(9).getJoueurCasecochee()))) {
            matchencours.setJgagnant(matchencours.getCases().get(3).getJoueurCasecochee());
            matchencours.setEtatmatch(EtatMatch.TERMINE);

            ((VueMatch) o).close();

        } else {

            boolean matchnul = true;

            // ici, on vérifie si il y a match nul ou non
            for (int k = 1; k < matchencours.getCases().size(); k++) {

                if (matchencours.getCases().get(k).getJoueurCasecochee() == null) {
                    matchnul = false;
                }

            }

            // Si il y a match nul, on déclare que le match est terminé, on ferme l'interface
            if (matchnul == true) {
                matchencours.setEtatmatch(EtatMatch.TERMINE);

                match.close();

            } else {
                
            }
        }

        return matchencours;

    }

    // Méthode pour retirer un match des matchs à faire, si il est terminé
    public void retirermatchàfaire(Match match) {

        matchsàfaire.remove(match.getNumeromatch());
        matchsfaits.put(match.getNumeromatch(), match);

    }

    // Méthode pour trier les joueurs et les afficher dans l'ordre du meilleur au moins bon, dans l'interface de classement, en fonction de leur score
    public ArrayList<Joueur> genererListeClassement(ArrayList<Joueur> listejoueurs) {

        ArrayList<Joueur> joueurstrié = listejoueurs;
        Collections.sort(joueurstrié, new ComparatorScore());
        return joueurstrié;

    }

}
