/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueAjouterJoueur extends Observable {

    private JFrame window;
    private JPanel mainPanel;
    private JTextField champseudo;
    private JButton boutonvalider, boutonannuler;
    private JComboBox champmode;

    VueAjouterJoueur(Mode mode) {

        window = new JFrame();

        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(600, 400);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);
        champmode = new JComboBox();

        //Si le mode choisi est adulte, on affiche l'interface en mode adulte, en mode enfant sinon
        if (mode == Mode.ADULTE) {
            affichageadulte();
        } else {
            affichageenfant();
        }

    }

    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }

    // ** METHODE POUR AFFICHAGE DE L'INTERFACE EN MODE ADULTE **
    private void affichageadulte() {

        JPanel panelmilieu = new JPanel(new GridLayout(6, 2));

        JPanel panelhaut = new JPanel();
        panelhaut.setBackground(Color.orange);
        JLabel titreajout = new JLabel("Ajouter un joueur");
        titreajout.setFont(new Font("Arial", Font.BOLD, 24));
        panelhaut.add(titreajout);

        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);

        Font font = new Font("Arial", Font.PLAIN, 18);

        boutonvalider = new JButton("Valider");
        boutonvalider.setFont(font);
        boutonannuler = new JButton("Annuler");
        boutonannuler.setFont(font);

        // Ajout des champs texte / Labels / boutons dans le panel du milieu
        for (int i = 1; i <= 12; i++) {

            JLabel casevide = new JLabel("");

            if (i == 3) {
                JLabel ajout = new JLabel("Pseudonyme du joueur à ajouter : ", SwingConstants.CENTER);
                ajout.setFont(new Font("Arial", Font.BOLD, 16));
                panelmilieu.add(ajout);
            } else if (i == 4) {
                champseudo = new JTextField();
                champseudo.setFont(font);
                panelmilieu.add(champseudo);
            } else if (i == 7) {
                JLabel ajout = new JLabel("type d'interface : ", SwingConstants.CENTER);
                ajout.setFont(new Font("Arial", Font.BOLD, 16));
                panelmilieu.add(ajout);
            } else if (i == 8) {
                String[] typeint = { "Adulte", "Enfant" };
                champmode = new JComboBox(typeint);
                champmode.setFont(font);
                champmode.setSelectedIndex(0);  
                panelmilieu.add(champmode);
            } else if (i == 11) {

                boutonvalider.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.VALIDER_CONFIG, champseudo.getText(),champmode.getSelectedIndex()));
                        clearChanged();
                    }
                });
                panelmilieu.add(boutonvalider);

            } else if (i == 12) {

                boutonannuler.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.ANNULER));
                        clearChanged();
                    }
                });
                panelmilieu.add(boutonannuler);

            } else {
                panelmilieu.add(casevide);
            }

        }

    }

    // **METHODE POUR AFFICHAGE DE L'INTERFACE EN MODE ENFANT **
    private void affichageenfant() {
        window.setSize(600, 500);
        JPanel panelmilieu = new JPanel(new GridLayout(5, 2));
        panelmilieu.setBackground(Color.orange);

        JPanel panelhaut = new JPanel();
        panelhaut.setBackground(Color.green);
        JLabel titreajout = new JLabel("NOUVEAU JOUEUR");
        titreajout.setFont(new Font("Comic sans MS", Font.BOLD, 26));
        titreajout.setForeground(Color.blue);
        panelhaut.add(titreajout);

        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);

        boutonvalider = new JButton(new ImageIcon("src/morpion/btn_valider.png"));
        boutonannuler = new JButton(new ImageIcon("src/morpion/btn_annuler.png"));

        // Ajout des champs texte / Labels / boutons dans le panel du milieu
        for (int i = 1; i <= 10; i++) {

            JLabel casevide = new JLabel("");

            if (i == 1) {

                JLabel prenom = new JLabel("Je m'appelle...", SwingConstants.CENTER);
                prenom.setFont(new Font("Comic sans MS", Font.BOLD, 24));
                panelmilieu.add(prenom);

            } else if (i == 2) {

                champseudo = new JTextField();
                champseudo.setFont(new Font("Comic sans MS", Font.PLAIN, 24));
                panelmilieu.add(champseudo);
                
            } else if (i == 5) {
                JLabel ajout = new JLabel("Je suis un... : ", SwingConstants.CENTER);
                ajout.setFont(new Font("Comic sans MS", Font.BOLD, 26));
                panelmilieu.add(ajout);
            } else if (i == 6) {
                String[] typeint = { "Adulte", "Enfant" };
                champmode = new JComboBox(typeint);
                champmode.setFont(new Font("Comic sans MS", Font.BOLD, 26));
                champmode.setSelectedIndex(1);                
                panelmilieu.add(champmode);

            } else if (i == 9) {

                boutonvalider.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.VALIDER_CONFIG, champseudo.getText(),champmode.getSelectedIndex()));
                        clearChanged();
                    }
                });
                panelmilieu.add(boutonvalider);

            } else if (i == 10) {

                boutonannuler.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.ANNULER));
                        clearChanged();
                    }
                });
                panelmilieu.add(boutonannuler);

            } else {
                panelmilieu.add(casevide);
            }

        }

    }

}
