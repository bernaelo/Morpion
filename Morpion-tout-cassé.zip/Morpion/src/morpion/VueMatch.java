/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author bernaelo
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueMatch extends Observable {

    private JFrame window;
    private ArrayList<JToggleButton> lboutonadulte = new ArrayList<>(); // Sert uniquement pour l'affichage adulte
    private ArrayList<JButton> lboutonenfant = new ArrayList<>(); // Sert uniquement pour l'affichage enfant
    private JLabel guidage; // Sert uniquement pour l'affichage adulte
    private JLabel erreur;
    private JPanel mainPanel;
    private JPanel panelmilieu;
    private JLabel fleche; // Sert uniquement pour l'affichage enfant
    private JLabel fleche2; // Sert uniquement pour l'affichage enfant

    VueMatch(Match match) {

        window = new JFrame();

        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(1200, 625);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);
        guidage=new JLabel();
        fleche = new JLabel(new ImageIcon("src/morpion/fleche.png"), SwingConstants.HORIZONTAL);
        fleche2 = new JLabel(new ImageIcon("src/morpion/fleche.png"), SwingConstants.HORIZONTAL);
        panelmilieu = new JPanel(new BorderLayout());

        //Si le mode choisi est adulte, on affiche l'interface en mode adulte, en mode enfant sinon
        revalider(match);

    }
    
    public void revalider(Match match){
        if (match.getJcourant().getTypej() == Mode.ADULTE) {
            affichageadulte(match);
        } else {
            affichageenfant(match);
        }
    }

    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }

    // ** METHODE POUR AFFICHAGE DE L'INTERFACE EN MODE ADULTE **
    private void affichageadulte(Match match) {
        
        mainPanel.removeAll();
        panelmilieu.removeAll();
        int a=1;
        for(JToggleButton b : lboutonadulte){
                
            try{
                if (match.getCases().get(a).getJoueurCasecochee() == match.getJ1()) {
                    b.setIcon(new ImageIcon("src/morpion/case_rond.png"));
                } else if(match.getCases().get(a).getJoueurCasecochee() == match.getJ2()) {
                    b.setIcon(new ImageIcon("src/morpion/case_croix.png"));
                }            
            }
            catch(NullPointerException e)
            {
        }            
            a++;
        }
        getGuidage().setText("Match n°" + match.getNumeromatch() + " : " + "A " + match.getJcourant().getPseudo() + " ! - Sélectionne une case");
                    
        
        
        JPanel panelmilieu1 = new JPanel(new GridLayout(2, 3));
        JPanel panelmilieu2 = new JPanel(new GridLayout(3, 3));

        panelmilieu.add(panelmilieu1, BorderLayout.NORTH);
        panelmilieu.add(panelmilieu2, BorderLayout.CENTER);

        JPanel panelbas = new JPanel(new GridLayout(1, 3));

        JPanel panelhaut = new JPanel();
        JLabel titrejouer = new JLabel("Jouer un match");
        titrejouer.setFont(new Font("Arial", Font.BOLD, 24));
        panelhaut.add(titrejouer);
        panelhaut.setBackground(Color.orange);

        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);
        mainPanel.add(BorderLayout.SOUTH, panelbas);

        JButton boutonvalider = new JButton("Valider la sélection");
        boutonvalider.setFont(new Font("Arial", Font.PLAIN, 18));
        boutonvalider.setPreferredSize(new Dimension(100, 75));
        ButtonGroup bgroup = new ButtonGroup();

        // Ajout des éléments d'informations sur le match, dans le panel milieu n°1 (Signes, joueurs etc..)
        for (int k = 1; k <= 6; k++) {

            JLabel casevide = new JLabel("");

            if (k == 2) {
                guidage = new JLabel("Match n°" + match.getNumeromatch() + " : " + "A " + match.getJcourant().getPseudo() + " ! - Sélectionne une case", SwingConstants.CENTER);
                guidage.setFont(new Font("Arial", Font.ITALIC, 18));
                panelmilieu1.add(guidage);
            } else if (k == 1) {
                JLabel img1 = new JLabel(new ImageIcon("src/morpion/case_rond.png"));
                img1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                img1.setPreferredSize(new Dimension(72, 85));
                panelmilieu1.add(img1);
            } else if (k == 3) {
                JLabel img2 = new JLabel(new ImageIcon("src/morpion/case_croix.png"));
                img2.setPreferredSize(new Dimension(72, 85));
                panelmilieu1.add(img2);
            } else if (k == 4) {
                JLabel infoj1 = new JLabel(match.getJ1().getPseudo(), SwingConstants.CENTER);
                infoj1.setFont(new Font("Arial", Font.BOLD, 20));
                panelmilieu1.add(infoj1);
            } else if (k == 5) {
                erreur = new JLabel("");
                panelmilieu1.add(erreur);
            } else if (k == 6) {
                JLabel infoj2 = new JLabel(match.getJ2().getPseudo(), SwingConstants.CENTER);
                infoj2.setFont(new Font("Arial", Font.BOLD, 20));
                panelmilieu1.add(infoj2);
            } else {
                panelmilieu1.add(casevide);
            }

        }

        // Ajout de la grille de 9 cases, dans le panel milieu n°2
        for (int i = 1; i <= 9; i++) {

            JToggleButton bt = new JToggleButton("");
            bt.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1));
            bgroup.add(bt);
            getLboutonadulte().add(bt);
            panelmilieu2.add(bt);

        }

        panelbas.add(new JLabel(""));

        // Bouton valider pour valider sa sélection de case
        boutonvalider.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setChanged();

                // Lorsque l'utilisateur valide, on vérifie si la case est déjà prise ou non, si oui, on ne transmet rien au contrôleur et on fait apparaître un message d'erreur sur l'interface
                for (int j = 0; j < getLboutonadulte().size(); j++) {
                    if (getLboutonadulte().get(j).isSelected()) {
                        if (getLboutonadulte().get(j).getIcon() == null) {
                            notifyObservers(new Message(Actions.VALIDER, match, j + 1));
                            erreur.setVisible(false);
                            erreur.revalidate();
                        } else {
                            this.declenchererreur(); // Apparition du message d'erreur sur l'interface
                        }
                    }
                }

                clearChanged();

            }

            private void declenchererreur() {
                erreur.setText("ERREUR : Cette case est déjà validée");
                erreur.setHorizontalAlignment(0);
                erreur.setFont(new Font("Arial", Font.BOLD, 18));
                erreur.setForeground(Color.red);
                erreur.setVisible(true);
                erreur.revalidate();
            }

        });

        panelbas.add(boutonvalider);

        panelbas.add(new JLabel(""));
        mainPanel.revalidate();
    }

    // **METHODE POUR AFFICHAGE DE L'INTERFACE EN MODE ENFANT **
    private void affichageenfant(Match match) {
        mainPanel.removeAll();
        panelmilieu.removeAll();
        
        
        if (match.getJcourant() == match.getJ1()) {
            getFleche2().setVisible(true);
            getFleche().setVisible(false);
        } else {                       
            getFleche2().setVisible(false);
            getFleche().setVisible(true);
        }
        JPanel panelmilieu1 = new JPanel(new GridLayout(3, 3));
        panelmilieu1.setBackground(Color.orange);
        JPanel panelmilieu2 = new JPanel(new GridLayout(3, 3));

        panelmilieu.add(panelmilieu1, BorderLayout.NORTH);
        panelmilieu.add(panelmilieu2, BorderLayout.CENTER);

        JPanel panelbas = new JPanel(new GridLayout(1, 3));

        JPanel panelhaut = new JPanel();
        JLabel titrejouer = new JLabel("JOUER");
        titrejouer.setFont(new Font("Comic Sans MS", Font.BOLD, 26));
        titrejouer.setForeground(Color.blue);
        panelhaut.add(titrejouer);
        panelhaut.setBackground(Color.green);

        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);
        mainPanel.add(BorderLayout.SOUTH, panelbas);

        ButtonGroup bgroup = new ButtonGroup();

        // Ajout des éléments d'informations sur le match, dans le panel milieu n°1 (Signes, joueurs etc..)
        for (int k = 1; k <= 9; k++) {

            JLabel casevide = new JLabel("");

            if (k == 1) {
                JLabel infoj1 = new JLabel(match.getJ1().getPseudo(), SwingConstants.CENTER);
                infoj1.setFont(new Font("Comic Sans MS", Font.BOLD, 24));
                infoj1.setForeground(Color.red);
                panelmilieu1.add(infoj1);
            } else if (k == 3) {
                JLabel infoj2 = new JLabel(match.getJ2().getPseudo(), SwingConstants.CENTER);
                infoj2.setFont(new Font("Comic Sans MS", Font.BOLD, 24));
                infoj2.setForeground(Color.red);
                panelmilieu1.add(infoj2);
            } else if (k == 4) {
                JLabel img1 = new JLabel(new ImageIcon("src/morpion/case_rond.png"), SwingConstants.HORIZONTAL);
                img1.setPreferredSize(new Dimension(72, 72));
                panelmilieu1.add(img1);
            } else if (k == 6) {
                JLabel img2 = new JLabel(new ImageIcon("src/morpion/case_croix.png"), SwingConstants.HORIZONTAL);
                img2.setPreferredSize(new Dimension(72, 72));
                panelmilieu1.add(img2);
            } else if (k == 5) {
                JLabel infomatch = new JLabel(new ImageIcon("src/morpion/logo_vs.png"), SwingConstants.HORIZONTAL);
                infomatch.setPreferredSize(new Dimension(72, 72));
                panelmilieu1.add(infomatch);
            } else if (k == 7) {
                panelmilieu1.add(fleche);
            } else if (k == 8) {
                erreur = new JLabel("");
                panelmilieu1.add(erreur);
            } else if (k == 9) {
                fleche2.setVisible(false);
                panelmilieu1.add(fleche2);
            } else {
                panelmilieu1.add(casevide);
            }
        }

        // Ajout de la grille de 9 cases, dans le panel milieu n°2
        for (int i = 1; i <= 9; i++) {

            JButton bt = new JButton("");
            bt.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1));
            bgroup.add(bt);
            // les cases de l'interface (sous forme de boutons) sont présentes dans une Arraylist avec des indices
            getLboutonenfant().add(bt);

            int nb = i;

            bt.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    setChanged();

                    // On vérifie si la case sélectionnée  par l'utilisateur est déjà prise ou non, si oui, on ne transmet rien au contrôleur et on fait apparaître un message d'erreur sur l'interface
                    if (getLboutonenfant().get(nb - 1).getIcon() == null) {
                        notifyObservers(new Message(Actions.VALIDER, match, nb));
                        erreur.setVisible(false);
                        erreur.revalidate();
                    } else {
                        declenchererreur(); // Apparition du message d'erreur sur l'interface
                    }

                    clearChanged();
                }
                
                

                private void declenchererreur() {
                    erreur.setText("Choisis une autre case !");
                    erreur.setHorizontalAlignment(0);
                    erreur.setFont(new Font("Arial", Font.BOLD, 16));
                    erreur.setForeground(Color.red);
                    erreur.setVisible(true);
                    erreur.revalidate();
                }

            });

            panelmilieu2.add(bt);
        }
        int a=1;
                for(JButton b : lboutonenfant){                
                    try{
                        if (match.getCases().get(a).getJoueurCasecochee() == match.getJ1()) {
                            b.setIcon(new ImageIcon("src/morpion/case_rond.png"));
                        } else if(match.getCases().get(a).getJoueurCasecochee() == match.getJ2()) {
                            b.setIcon(new ImageIcon("src/morpion/case_croix.png"));
                        }            
                    }
                    catch(NullPointerException e)
                    {
                }            
                    a++;
                }
        
        mainPanel.revalidate();

    }

    //Sert uniquement pour l'affichage adulte
    public JLabel getGuidage() {
        return guidage;
    }

    //Sert uniquement pour l'affichage enfant
    public JLabel getFleche() {
        return fleche;
    }

    //Sert uniquement pour l'affichage enfant
        public JLabel getFleche2() {
        return fleche2;
    }

    /**
     * @return the lboutonadulte
     */
    public ArrayList<JToggleButton> getLboutonadulte() {
        return lboutonadulte;
    }

    /**
     * @return the lboutonenfant
     */
    public ArrayList<JButton> getLboutonenfant() {
        return lboutonenfant;
    }

}
