/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author bernaelo
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueSupprimerJoueur extends Observable {

    private JFrame window;
    JPanel mainPanel;
    JButton boutonvalider, boutonannuler;
    private ArrayList<JToggleButton> boutonsjoueurssuppr = new ArrayList<>(); // Uniquement pour l'affichage de l'interface mode enfant

    VueSupprimerJoueur(ArrayList<Joueur> h, Mode mode) {

        window = new JFrame();

        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(600, 400);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);

        //Si le mode choisi est adulte, on affiche l'interface en mode adulte, en mode enfant sinon
        if (mode == Mode.ADULTE) {
            affichageadulte(h);
        } else {
            affichageenfant(h);
        }

    }

    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }

    // ** METHODE POUR AFFICHAGE DE L'INTERFACE EN MODE ADULTE **
    private void affichageadulte(ArrayList<Joueur> h) {

        JPanel panelmilieu = new JPanel(new GridLayout(4, 2));

        JPanel panelhaut = new JPanel();
        JLabel titresuppr = new JLabel("Supprimer un joueur");
        titresuppr.setFont(new Font("Arial", Font.BOLD, 24));
        panelhaut.add(titresuppr);
        panelhaut.setBackground(Color.orange);

        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);

        Font font = new Font("Arial", Font.PLAIN, 18);

        // Miste sous forme de liste déroulante, la liste de joueurs
        String[] joueurs = new String[h.size()];
        for (int c = 0; c < h.size(); c++) {
            joueurs[c] = h.get(c).getPseudo();
        }
        JComboBox listejoueurs;
        listejoueurs = new JComboBox(joueurs);
        listejoueurs.setFont(font);

        boutonvalider = new JButton("Valider");
        boutonvalider.setFont(font);
        boutonannuler = new JButton("Annuler");
        boutonannuler.setFont(font);

        // Ajout des champs texte / Labels / boutons dans le panel du milieu
        for (int i = 1; i <= 8; i++) {

            JLabel casevide = new JLabel("");

            if (i == 3) {
                JLabel suppr = new JLabel("Sélectionnez le joueur à supprimer : ", SwingConstants.CENTER);
                suppr.setFont(new Font("Arial", Font.BOLD, 16));
                panelmilieu.add(suppr);
            } else if (i == 4) {

                panelmilieu.add(listejoueurs);
            } else if (i == 7) {

                boutonvalider.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.VALIDER_CONFIG, listejoueurs.getSelectedIndex()));
                        clearChanged();
                    }
                });

                panelmilieu.add(boutonvalider);

            } else if (i == 8) {

                boutonannuler.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.ANNULER, listejoueurs.getSelectedIndex()));
                        clearChanged();
                    }
                });

                panelmilieu.add(boutonannuler);

            } else {
                panelmilieu.add(casevide);
            }

        }

    }

    // **METHODE POUR AFFICHAGE DE L'INTERFACE EN MODE ENFANT **
    private void affichageenfant(ArrayList<Joueur> h) {

        JPanel panelmilieu = new JPanel(new GridLayout(h.size(), 1));
        panelmilieu.setBackground(Color.orange);

        JPanel panelhaut = new JPanel();
        JLabel titresuppr = new JLabel("SUPPRIMER UN JOUEUR");
        titresuppr.setFont(new Font("Comic sans MS", Font.BOLD, 26));
        titresuppr.setForeground(Color.blue);
        panelhaut.add(titresuppr);
        panelhaut.setBackground(Color.green);

        JPanel panelbas = new JPanel(new GridLayout(1, 3));
        panelbas.setBackground(Color.orange);

        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);
        mainPanel.add(BorderLayout.SOUTH, panelbas);

        // On génère des boutons pour chaque joueur que l'on peut supprimer, selon la liste des joueurs
        for (int c = 0; c < h.size(); c++) {

            JButton bouton = new JButton(h.get(c).getPseudo());
            bouton.setFont(new Font("Comic sans MS", Font.BOLD, 32));
            int positiondansliste = c;

            bouton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    setChanged();

                    notifyObservers(new Message(Actions.VALIDER_CONFIG, positiondansliste));

                    clearChanged();
                }
            });

            panelmilieu.add(bouton);

        }

        boutonannuler = new JButton(new ImageIcon("src/morpion/btn_annuler.png"));

        panelbas.add(new JLabel(""));

        boutonannuler.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setChanged();
                notifyObservers(new Message(Actions.ANNULER));
                clearChanged();
            }
        });

        panelbas.add(boutonannuler);

        panelbas.add(new JLabel(""));

    }

    // Uniquement pour l'affchage de l'interface mode enfant
    public ArrayList<JToggleButton> getBoutonsjoueurssuppr() {
        return boutonsjoueurssuppr;
    }

}
