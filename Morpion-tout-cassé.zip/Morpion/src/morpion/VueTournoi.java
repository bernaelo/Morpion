/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author kemplail
 */
public class VueTournoi extends Observable {

    private final JFrame window;
    private JButton boutonajouter, boutonsupprimer, boutoncommencer;
    private JPanel panelgauche;
    private JPanel panelhaut;    
    private JPanel panelmilieu; 
    private JPanel panelcentre; 
    private JPanel panelbas;
    private JPanel panelliste;
    private JPanel mainPanel;
    private JLabel erreur;
    private Mode mode;
    private JButton btnmode;

    VueTournoi(ArrayList<Joueur> h) {

        window = new JFrame();

        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(950, 500);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);

        mainPanel = new JPanel(new BorderLayout());
        panelhaut = new JPanel();
        panelmilieu = new JPanel();
        panelcentre = new JPanel();
        panelbas = new JPanel();
        window.add(mainPanel);
        this.mode = Mode.ADULTE;

        revalider(h);

    }

    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }

    // ** METHODE POUR AFFICHAGE DE L'INTERFACE **
    public void revalider(ArrayList<Joueur> h) {
        
        if (this.getMode()==Mode.ADULTE){
            panelhaut.removeAll();
            panelmilieu.removeAll();
            panelcentre.removeAll();
            
            panelmilieu = new JPanel(new GridLayout(7, 2));
            
            panelhaut = new JPanel(new BorderLayout());
            panelhaut.setBackground(Color.orange);
            JLabel tournoi = new JLabel("Créer un tournoi", SwingConstants.CENTER);
            tournoi.setFont(new Font("Arial", Font.BOLD, 24));
            panelhaut.add(tournoi, BorderLayout.CENTER);
            
            btnmode=new JButton("Mode Enfant");
            btnmode.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            setChanged();
                            notifyObservers(new Message(Actions.CHANGE_MODE));
                            erreur.setVisible(false);
                            erreur.revalidate();
                            clearChanged();
                        }
                    });
            panelhaut.add(btnmode, BorderLayout.WEST);
            
            panelgauche = new JPanel(new BorderLayout());

            panelliste = new JPanel(new GridLayout(3, 1));
            panelliste.add(new JLabel(""));
            JLabel liste = new JLabel("  Liste des joueurs : ");
            liste.setFont(new Font("Arial", Font.ITALIC, 18));
            panelliste.add(liste);
            panelliste.add(new JLabel(""));

            panelbas = new JPanel();
            JLabel info = new JLabel("Information : Veuillez ajouter au minimum 2 joueurs, pour commencer le tournoi");
            info.setFont(new Font("Arial", Font.ITALIC, 17));
            panelbas.add(info);
            panelbas.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 1));

            Font font = new Font("Arial", Font.BOLD, 18);
            Font font2 = new Font("Arial", Font.PLAIN, 19);

            mainPanel.add(BorderLayout.NORTH, panelhaut);
            mainPanel.add(BorderLayout.CENTER, panelmilieu);
            mainPanel.add(BorderLayout.WEST, panelgauche);
            mainPanel.add(BorderLayout.SOUTH, panelbas);

            // Méthode pour afficher la liste des joueurs, qui peut être actualisée si un joueur est ajouté à cette liste
            actualiser(h);

            boutonajouter = new JButton("Ajouter");
            boutonajouter.setFont(font2);
            boutonsupprimer = new JButton("Supprimer");
            boutonsupprimer.setFont(font2);
            boutoncommencer = new JButton("Commencer");
            boutoncommencer.setFont(font2);

            // Ajout des labels / boutons dans le panelmilieu
            for (int i = 1; i <= 14; i++) {

                JLabel casevide = new JLabel("");

                if (i == 4) {

                    boutonajouter.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            setChanged();
                            notifyObservers(new Message(Actions.DEMANDE_AJOUT));
                            erreur.setVisible(false);
                            erreur.revalidate();
                            clearChanged();
                        }
                    });
                    panelmilieu.add(boutonajouter);

                } else if (i == 3) {

                    JLabel ajout = new JLabel("Ajouter un nouveau joueur : ", SwingConstants.CENTER);
                    ajout.setFont(font);
                    panelmilieu.add(ajout);

                } else if (i == 1) {

                    erreur = new JLabel("");
                    panelmilieu.add(erreur);

                } else if (i == 7) {

                    JLabel supprimer = new JLabel("Supprimer un joueur existant : ", SwingConstants.CENTER);
                    supprimer.setFont(font);
                    panelmilieu.add(supprimer);

                } else if (i == 11) {
                    JLabel commencer = new JLabel("Commencer le tournoi : ", SwingConstants.CENTER);
                    commencer.setFont(font);
                    panelmilieu.add(commencer);
                } else if (i == 8) {

                    boutonsupprimer.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            setChanged();
                            notifyObservers(new Message(Actions.DEMANDE_SUPPRIMER));
                            clearChanged();
                        }
                    });
                    panelmilieu.add(boutonsupprimer);
                } else if (i == 12) {

                    boutoncommencer.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            setChanged();
                            notifyObservers(new Message(Actions.COMMENCER_TOURNOI));
                            clearChanged();
                        }
                    });
                    panelmilieu.add(boutoncommencer);

                } else {

                    panelmilieu.add(casevide);

                }

            }
        } else if (getMode()==Mode.ENFANT){
            panelhaut.removeAll();
            panelmilieu.removeAll();
            panelcentre.removeAll();
            
            panelhaut = new JPanel(new BorderLayout());
            panelhaut.setBackground(Color.orange);
            JLabel tournoi = new JLabel("JEU DU MORPION", SwingConstants.CENTER);
            tournoi.setFont(new Font("Arial", Font.BOLD, 24));
            panelhaut.add(tournoi, BorderLayout.CENTER);
            
            btnmode=new JButton("Mode Adulte");
            btnmode.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            setChanged();
                            notifyObservers(new Message(Actions.CHANGE_MODE));
                            erreur.setVisible(false);
                            erreur.revalidate();
                            clearChanged();
                        }
                    });
            panelhaut.add(btnmode, BorderLayout.WEST);
            
            panelcentre = new JPanel(new BorderLayout());
            panelmilieu = new JPanel(new GridLayout(2, 3));
            panelmilieu.setBackground(Color.orange);
            panelcentre.add(panelmilieu, BorderLayout.CENTER);
            erreur = new JLabel("");
            panelcentre.add(BorderLayout.SOUTH, erreur);


        panelgauche = new JPanel(new BorderLayout());

        panelliste = new JPanel(new GridLayout(3, 1));
        panelliste.add(new JLabel(""));
        JLabel liste = new JLabel("  PRENOMS : ");
        liste.setFont(new Font("Arial", Font.ITALIC, 16));
        panelliste.add(liste);
        panelliste.add(new JLabel(""));

        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelcentre);
        mainPanel.add(BorderLayout.WEST, panelgauche);

        // Méthode pour afficher la liste des joueurs, qui peut être actualisée si un joueur est ajouté à cette liste
        actualiser(h);

        boutonajouter = new JButton(new ImageIcon("src/morpion/add-user.png"));
        boutonsupprimer = new JButton(new ImageIcon("src/morpion/remove-user.png"));
        boutoncommencer = new JButton(new ImageIcon("src/morpion/Start-icon.png"));

        // Ajout des boutons, images, labels au panel du milieu
        for (int i = 1; i <= 6; i++) {

            JLabel casevide = new JLabel("");

            if (i == 2) {

                JLabel image = new JLabel(new ImageIcon("src/morpion/image-enfant.jpg"));
                panelmilieu.add(image);

            } else if (i == 4) {

                boutonajouter.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.DEMANDE_AJOUT));
                        erreur.setVisible(false);
                        erreur.revalidate();
                        clearChanged();
                    }
                });
                panelmilieu.add(boutonajouter);

            } else if (i == 5) {

                boutonsupprimer.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.DEMANDE_SUPPRIMER));
                        clearChanged();
                    }
                });
                panelmilieu.add(boutonsupprimer);

            } else if (i == 6) {

                boutoncommencer.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                        notifyObservers(new Message(Actions.COMMENCER_TOURNOI));
                        clearChanged();
                    }
                });
                panelmilieu.add(boutoncommencer);

            } else {

                panelmilieu.add(casevide);

            }
        }
        }

    }


    void actualiser(ArrayList<Joueur> h) {

        panelgauche.removeAll();
        panelgauche.add(BorderLayout.NORTH, panelliste);
        String[] joueurs = new String[h.size()];
        for (int c = 0; c < h.size(); c++) {
            joueurs[c] = h.get(c).getPseudo();
        }
        JList listejoueurs;
        listejoueurs = new JList(joueurs);
        listejoueurs.setFont(new Font("Arial", Font.PLAIN, 16));

        panelgauche.add(BorderLayout.CENTER, listejoueurs);
        panelgauche.revalidate();

    }

    // Méthode pour déclencher une erreur, si l'utilisateur n'a pas ajouté au moins 2 joueurs
    void declenchererreur() {

        if (getMode() == Mode.ADULTE) {
            erreur.setText("ERREUR : Veuillez ajouter au moins 2 joueurs");
            erreur.setHorizontalAlignment(0);
            erreur.setFont(new Font("Arial", Font.BOLD, 16));
            erreur.setForeground(Color.red);
            erreur.setVisible(true);
            erreur.revalidate();
        } else {

            erreur.setText("Il faut que tu ajoutes encore des joueurs pour commencer ! ");
            erreur.setHorizontalAlignment(0);
            erreur.setFont(new Font("Arial", Font.BOLD, 20));
            erreur.setForeground(Color.red);
            erreur.setVisible(true);
            erreur.revalidate();

        }

    }

    /**
     * @return the mode
     */
    public Mode getMode() {
        return mode;
    }

    /**
     * @param mode the mode to set
     */
    public void setMode(Mode mode) {
        this.mode = mode;
    }

}
