/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.util.HashMap;

/**
 *
 * @author kemplail
 */
public class Match {
    
     private HashMap<Integer,Case> cases;
    private Integer numeromatch;
    private Joueur j1;
    private Joueur j2;
    private HashMap<Joueur,Signe> joueursigne ;
    private Joueur jcourant;
    private Joueur jgagnant = null;
    private EtatMatch etatmatch = EtatMatch.EN_COURS;
    
    Match(HashMap<Integer,Case> cases, int numeromatch, Joueur j1, Joueur j2, HashMap<Joueur,Signe> joueursigne) {
        this.setCases(cases);
        this.setNumeromatch(numeromatch);
        this.setJ1(j1);
        this.setJ2(j2);
        this.setJoueursigne(joueursigne);
        this.setJcourant(j1);
    }
    
    /**
     * @return the cases
     */
    public HashMap<Integer,Case> getCases() {
        return cases;
    }

    /**
     * @param cases the cases to set
     */
    public void setCases(HashMap<Integer,Case> cases) {
        this.cases = cases;
    }

    /**
     * @return the numeromatch
     */
    public Integer getNumeromatch() {
        return numeromatch;
    }

    /**
     * @param numeromatch the numeromatch to set
     */
    public void setNumeromatch(Integer numeromatch) {
        this.numeromatch = numeromatch;
    }

    /**
     * @return the j1
     */
    public Joueur getJ1() {
        return j1;
    }

    /**
     * @param j1 the j1 to set
     */
    public void setJ1(Joueur j1) {
        this.j1 = j1;
    }

    /**
     * @return the j2
     */
    public Joueur getJ2() {
        return j2;
    }

    /**
     * @param j2 the j2 to set
     */
    public void setJ2(Joueur j2) {
        this.j2 = j2;
    }

    /**
     * @return the joueursigne
     */
    public HashMap<Joueur,Signe> getJoueursigne() {
        return joueursigne;
    }

    /**
     * @param joueursigne the joueursigne to set
     */
    public void setJoueursigne(HashMap<Joueur,Signe> joueursigne) {
        this.joueursigne = joueursigne;
    }
    
    public Signe getSigneDeJoueur(Joueur j) {
        return joueursigne.get(j);
    }
    
    public Signe getSigne(Joueur j){
        return joueursigne.get(j);
    }

    /**
     * @return the jcourant
     */
    public Joueur getJcourant() {
        return jcourant;
    }

    /**
     * @param jcourant the jcourant to set
     */
    public void setJcourant(Joueur jcourant) {
        this.jcourant = jcourant;
    }

    /**
     * @return the jgagnant
     */
    public Joueur getJgagnant() {
        return jgagnant;
    }

    /**
     * @param jgagnant the jgagnant to set
     */
    public void setJgagnant(Joueur jgagnant) {
        this.jgagnant = jgagnant;
    }

    /**
     * @return the etatmatch
     */
    public EtatMatch getEtatmatch() {
        return etatmatch;
    }

    /**
     * @param etatmatch the etatmatch to set
     */
    public void setEtatmatch(EtatMatch etatmatch) {
        this.etatmatch = etatmatch;
    }
}
