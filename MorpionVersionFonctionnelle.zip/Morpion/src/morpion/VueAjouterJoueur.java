/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueAjouterJoueur extends Observable {
    
    private JFrame window;
    private JTextField champseudo;
    JButton boutonvalider;
    
    VueAjouterJoueur() {
    
     window = new JFrame();
        
        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(800, 600);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width/2-window.getSize().width/2, dim.height/2-window.getSize().height/2);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);
        JPanel panelmilieu = new JPanel(new GridLayout(4,2));
        JPanel panelhaut = new JPanel();
        panelhaut.add(new JLabel("Ajouter un joueur"));
        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);
        
        boutonvalider = new JButton("Valider");
    
        for (int i = 1; i <= 8; i++) {
            
            JLabel casevide = new JLabel("");
            
            if (i == 1) {
                panelmilieu.add(new JLabel(new ImageIcon("C:/Users/Fayzy/Desktop/ajouterjoueur.jpg")));
            }
            
            else if (i == 3) {
                panelmilieu.add(new JLabel("Pseudonyme du joueur : ",SwingConstants.CENTER));
            }
            
            else if (i == 4) {
                champseudo = new JTextField();
                panelmilieu.add(champseudo);
            }
            
            else if (i == 7) {
                
                boutonvalider.addActionListener(new ActionListener() {
                @Override
                   public void actionPerformed(ActionEvent e) {
                        setChanged();
                            notifyObservers(new Message(Actions.VALIDER, champseudo.getText()));
                        clearChanged();
            }   
        });
            panelmilieu.add(boutonvalider);
            
            }
            
            else {
                panelmilieu.add(casevide);
            }
            
        }
        
    }
       
     public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }
    
}