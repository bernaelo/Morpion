/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author bernaelo
 */
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author Fayzy
 */
public class VueMatch extends Observable {
    
    private JFrame window;
    JButton boutonvalider;
    private ButtonGroup bgroup;
    private JRadioButton case1;
    private JRadioButton case2;
    private JRadioButton case3;
    private JRadioButton case4;
    private JRadioButton case5;
    private JRadioButton case6;
    private JRadioButton case7;
    private JRadioButton case8;
    private JRadioButton case9;
    
    VueMatch(Match match) {
    
     window = new JFrame();
        
        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(800, 600);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width/2-window.getSize().width/2, dim.height/2-window.getSize().height/2);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);
        JPanel panelmilieu = new JPanel(new GridLayout(5,4));
        JPanel panelhaut = new JPanel();
        panelhaut.add(new JLabel("Jouer un match"));
        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);
        
        boutonvalider = new JButton("Valider");
        bgroup = new ButtonGroup();
        
        case1 = new JRadioButton();
        case2 = new JRadioButton();
        case3 = new JRadioButton();
        case4 = new JRadioButton();
        case5 = new JRadioButton();
        case6 = new JRadioButton();
        case7 = new JRadioButton();
        case8 = new JRadioButton();
        case9 = new JRadioButton();
        
        bgroup.add(case1);
        bgroup.add(case2);
        bgroup.add(case3);
        bgroup.add(case4);
        bgroup.add(case5);
        bgroup.add(case6);
        bgroup.add(case7);
        bgroup.add(case8);
        bgroup.add(case9);
        
    
        for (int i = 1; i <= 20; i++) {
            
            JLabel casevide = new JLabel("");
            
            if (i == 1) {
                 panelmilieu.add(new JLabel(match.getSigne(match.getJ1()).toString()));
            }
            
            else if (i == 2) {
                if(match.getJcourant().equals(match.getJ1())){
                    panelmilieu.add(new JLabel(match.getJ1().getPseudo()+" joue"));
                }else{
                    panelmilieu.add(new JLabel(match.getJ1().getPseudo()));
                }
                    
            }
            
            else if (i == 3) {
                
                if(match.getJcourant().equals(match.getJ2())){
                    panelmilieu.add(new JLabel(match.getJ2().getPseudo()+" joue"));
                }else{
                    panelmilieu.add(new JLabel(match.getJ2().getPseudo()));
                }
            }
            
            else if (i == 4) {
                
                panelmilieu.add(new JLabel(match.getSigne(match.getJ2()).toString()));
            }
            
            else if (i == 9) {
                
                if(match.getCases().get(1).getJoueurCasecochee()==match.getJ1()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ1()).toString()));
                } else if(match.getCases().get(1).getJoueurCasecochee()==match.getJ2()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ2()).toString()));
                } else{
                    panelmilieu.add(case1);
                }
                
            }
            
            else if (i == 10) {
                
                if(match.getCases().get(2).getJoueurCasecochee()==match.getJ1()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ1()).toString()));
                } else if(match.getCases().get(2).getJoueurCasecochee()==match.getJ2()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ2()).toString()));
                } else{
                    panelmilieu.add(case2);
                }
                
            }
            
            else if (i == 11) {
                
                if(match.getCases().get(3).getJoueurCasecochee()==match.getJ1()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ1()).toString()));
                } else if(match.getCases().get(3).getJoueurCasecochee()==match.getJ2()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ2()).toString()));
                } else{
                    panelmilieu.add(case3);
                }
                
            }
            
            else if (i == 13) {
                
                if(match.getCases().get(4).getJoueurCasecochee()==match.getJ1()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ1()).toString()));
                } else if(match.getCases().get(4).getJoueurCasecochee()==match.getJ2()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ2()).toString()));
                } else{
                    panelmilieu.add(case4);
                }
                
            }
            
            else if (i == 14) {
                
                if(match.getCases().get(5).getJoueurCasecochee()==match.getJ1()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ1()).toString()));
                } else if(match.getCases().get(5).getJoueurCasecochee()==match.getJ2()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ2()).toString()));
                } else{
                    panelmilieu.add(case5);
                }
                
            }
            
            else if (i == 15) {
                
                if(match.getCases().get(6).getJoueurCasecochee()==match.getJ1()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ1()).toString()));
                } else if(match.getCases().get(6).getJoueurCasecochee()==match.getJ2()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ2()).toString()));
                } else{
                    panelmilieu.add(case6);
                }
                
            }
            
            else if (i == 17) {
                
                if(match.getCases().get(7).getJoueurCasecochee()==match.getJ1()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ1()).toString()));
                } else if(match.getCases().get(7).getJoueurCasecochee()==match.getJ2()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ2()).toString()));
                } else{
                    panelmilieu.add(case7);
                }
                
            }
            
            else if (i == 18) {
                
                if(match.getCases().get(8).getJoueurCasecochee()==match.getJ1()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ1()).toString()));
                } else if(match.getCases().get(8).getJoueurCasecochee()==match.getJ2()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ2()).toString()));
                } else{
                    panelmilieu.add(case8);
                }
                
            }
            
            else if (i == 19) {
                
                if(match.getCases().get(9).getJoueurCasecochee()==match.getJ1()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ1()).toString()));
                } else if(match.getCases().get(9).getJoueurCasecochee()==match.getJ2()){
                    panelmilieu.add(new JLabel(match.getSigne(match.getJ2()).toString()));
                } else{
                    panelmilieu.add(case9);
                }
                
            }
            
            else if (i == 16) {
                
                boutonvalider.addActionListener(new ActionListener() {
                @Override
                   public void actionPerformed(ActionEvent e) {
                        setChanged();
                        
                        int numcase = 0;
                        
                        if (case1.isSelected()){
                            numcase=1;
                        }
                        else if (case2.isSelected()){
                            numcase=2;
                        }
                        else if (case3.isSelected()){
                            numcase=3;
                        }
                        else if (case4.isSelected()){
                            numcase=4;
                        }
                        else if (case5.isSelected()){
                            numcase=5;
                        }
                        else if (case6.isSelected()){
                            numcase=6;
                        }
                        else if (case7.isSelected()){
                            numcase=7;
                        }
                        else if (case8.isSelected()){
                            numcase=8;
                        }
                        else if (case9.isSelected()){
                            numcase=9;
                        }
                        
                            notifyObservers(new Message(Actions.VALIDER, match, numcase));
                            
                        clearChanged();
                    }   
                });
                
                panelmilieu.add(boutonvalider);
            
            }
            
            else {
                panelmilieu.add(casevide);
            }
            
        }
        
    }
       
     public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }
    
}