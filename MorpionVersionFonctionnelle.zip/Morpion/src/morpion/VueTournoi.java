/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Observable;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author kemplail
 */
public class VueTournoi extends Observable {

    private final JFrame window;
    private final JButton boutonajouter, boutonsupprimer, boutoncommencer;
    
    VueTournoi(ArrayList<Joueur> h) {
        
        window = new JFrame();
        
        window.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        // Définit la taille de la fenêtre en pixels
        window.setSize(800, 600);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation(dim.width/2-window.getSize().width/2, dim.height/2-window.getSize().height/2);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        window.add(mainPanel);
        
        JPanel panelmilieu = new JPanel(new GridLayout(8,1));
        JPanel panelhaut = new JPanel();
        JPanel panelgauche = new JPanel(new BorderLayout());
        JPanel panelliste = new JPanel(new GridLayout(2,1));
        
        mainPanel.add(BorderLayout.NORTH, panelhaut);
        mainPanel.add(BorderLayout.CENTER, panelmilieu);
        mainPanel.add(BorderLayout.WEST, panelgauche);
        
        panelhaut.add(new JLabel("Créer un tournoi"));
        
        panelgauche.add(BorderLayout.NORTH, panelliste);
        panelliste.add(new JLabel("Liste des joueurs : "));
        panelliste.add(new JLabel(""));
        
        String[] joueurs = new String[h.size()];
                for(int c = 0;c<h.size();c++){
                    joueurs[c]=h.get(c).getPseudo();
                }
                JList listejoueurs;
                listejoueurs = new JList(joueurs);
               
        panelgauche.add(BorderLayout.CENTER, listejoueurs);
        
        boutonajouter = new JButton("Ajouter");
        boutonsupprimer = new JButton("Supprimer");
        boutoncommencer = new JButton("Commencer");
        
            for (int i = 1; i <= 8 ; i++) {
                
                JLabel casevide = new JLabel("");
                
                if (i == 2) {
                    
                    boutonajouter.addActionListener(new ActionListener() {
                @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                            notifyObservers(new Message(Actions.DEMANDE_AJOUT));
                        clearChanged();
            }   
        });
            panelmilieu.add(boutonajouter);
                    
                }
                
               else if (i == 1) {
                   
                   panelmilieu.add(new JLabel("Ajouter un nouveau joueur : ",SwingConstants.CENTER));
                   
               }
               
               else if (i == 4) {
                   
                   panelmilieu.add(new JLabel("Supprimer un joueur : ",SwingConstants.CENTER));
                   
               }
               
               else if (i == 7) {
                   panelmilieu.add(new JLabel("Commencer le tournoi : ",SwingConstants.CENTER));
               }
                
               else if (i == 5) {
                    
            boutonsupprimer.addActionListener(new ActionListener() {
                @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                            notifyObservers(new Message(Actions.SUPPRIMER));
                        clearChanged();
            }   
        });
            panelmilieu.add(boutonsupprimer);
                }
                
                else if (i == 8) {
                    
                    boutoncommencer.addActionListener(new ActionListener() {
                @Override
                    public void actionPerformed(ActionEvent e) {
                        setChanged();
                            notifyObservers(new Message(Actions.COMMENCER_TOURNOI));
                        clearChanged();
            }   
        });
            panelmilieu.add(boutoncommencer);
                    
                }
                  
                else {
                    
                    panelmilieu.add(casevide);
                    
                }
                
            }
       
        }
        
    
    public void afficher() {
        this.window.setVisible(true);
    }

    void close() {
        this.window.dispose();
    }
    
}