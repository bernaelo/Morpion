/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author kemplail
 */
public class Case {
    
    private Integer num;
    private Joueur casecochee;
    
    public Case(int num){
        this.num=num;
        casecochee=null;
    }

    /**
     * @return the num
     */
    public Integer getNum() {
        return num;
    }

//    /**
//     * @param num the num to set
//     */
//    public void setNum(Integer num) {
//        this.num = num;
//    }

    /**
     * @return the casecochee
     */
    public Joueur getJoueurCasecochee() {
        return casecochee;
    }

    /**
     * @param casecochee the casecochee to set
     */
    public void setJoueurCasecochee(Joueur casecochee) {
        this.casecochee = casecochee;
    }
    
    
}
