/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.util.ArrayList;

/**
 *
 * @author kemplail
 */
public class Message {
 
    private Actions action;
    private String pseudo = null;
    private int position = 0;
    private Match match;
    private int indicecase;
    
    Message(Actions action) {
        this.setAction(action);
    }
    
    Message(Actions action, String pseudo) {
        this.setAction(action);
        this.setPseudo(pseudo);
    }
    
    Message(Actions action, int position) {
        this.setAction(action);
        this.setPosition(position);
    }
    
    Message(Actions action, Match match, int indicecase) {
        this.setAction(action);
        this.setPosition(position);
        this.match=match;
        this.indicecase=indicecase;
    }

    /**
     * @return the action
     */
    public Actions getAction() {
        return action;
    }

    /**
     * @param action the action to set
     */
    public void setAction(Actions action) {
        this.action = action;
    }

    /**
     * @return the pseudo
     */
    public String getPseudo() {
        return pseudo;
    }

    /**
     * @param pseudo the pseudo to set
     */
    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    /**
     * @return the position
     */
    public int getPosition() {
        return position;
    }

    /**
     * @param position the position to set
     */
    public void setPosition(int position) {
        this.position = position;
    }

    /**
     * @return the match
     */
    public Match getMatch() {
        return match;
    }

    /**
     * @return the indicecase
     */
    public int getIndicecase() {
        return indicecase;
    }

    /**
     * @return the j1
     */

}
