/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

import java.util.HashMap;

/**
 *
 * @author kemplail
 */
public class Match {
    
    private HashMap<Integer,Case> cases;
    private Integer numeromatch;

    /**
     * @return the cases
     */
    public HashMap<Integer,Case> getCases() {
        return cases;
    }

    /**
     * @param cases the cases to set
     */
    public void setCases(HashMap<Integer,Case> cases) {
        this.cases = cases;
    }
    
}
