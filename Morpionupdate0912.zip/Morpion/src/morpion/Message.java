/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;

/**
 *
 * @author kemplail
 */
public class Message {
 
    private Actions action;
    private String pseudo = null;
    
    Message(Actions action) {
        this.setAction(action);
    }
    
    Message(Actions action, String pseudo) {
        this.setAction(action);
        this.setPseudo(pseudo);
    }

    /**
     * @return the action
     */
    public Actions getAction() {
        return action;
    }

    /**
     * @param action the action to set
     */
    public void setAction(Actions action) {
        this.action = action;
    }

    /**
     * @return the pseudo
     */
    public String getPseudo() {
        return pseudo;
    }

    /**
     * @param pseudo the pseudo to set
     */
    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }
    
}
