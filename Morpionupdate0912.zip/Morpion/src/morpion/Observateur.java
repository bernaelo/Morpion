/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morpion;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author bernaelo
 */
public class Observateur implements Observer {

    private HashMap<Integer,Joueur> joueurstournoi = new HashMap<>();
    private HashMap<Integer,Match> matchs = new HashMap<>();
    private VueTournoi vuetournoi;
    
    Observateur() {
        
        Joueur j1 = new Joueur("Hector");
        Joueur j2 = new Joueur("Gérald");
        joueurstournoi.put(1, j1);
        joueurstournoi.put(2, j2);
        vuetournoi = new VueTournoi(joueurstournoi);
        vuetournoi.addObserver(this);
        vuetournoi.afficher();
    }
    
    @Override
    public void update(Observable o, Object arg) {
        
        if (arg instanceof Message) {
            Message message = (Message) arg ;
            if (message.getAction() == Actions.AJOUTER && message.getPseudo() == null) {

                VueAjouterJoueur ajouter = new VueAjouterJoueur();
                ajouter.addObserver(this);
                ajouter.afficher();
                
        }
        
            else if (message.getAction() == Actions.AJOUTER && message.getPseudo() != null) {
                
                System.out.println(message.getPseudo());
                
            }
            
    }
  
    }
        
}
